<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<title>Registro de Representantes</title>
</head>
<body>

<div id="contenedor" >-->
  
<?php

include("includes/funciones.php");
include("inc/cabecera2.php");

 echo'<div id="agrupar">';

echo '<div id="main">';

;
$txtCodigo= "";
$txtNombre= "";
$txtDireccion= "";
$txtCorreo= "";
$txtTelefono= "";
$txtModo="I";
$txtTipo="";


if(isset($_POST['txtCodigo'])&& trim($_POST['txtCodigo']<>""))
  {
     $sql="select * from tbl_usuario where login ='".trim($_POST['txtCodigo'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['login'];
			 $txtNombre=$campo['nombre'];
			  $txtDireccion=$campo['direccion'];
			  $txtTelefono=$campo['telefono'];
			  $txtCorreo=$campo['correo'];
			  $txtTipo=$campo['tipo'];
			
			echo "<script> alert('Nombre de usuario no disponible intente otro');</script>";
		  
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Nombre de usuario disponible');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Registro de Usuarios
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Código</td>
  <td width="348" >
  <input type="text" name="txtCodigo" id="txtCodigo" value=" <?php echo $txtCodigo;?>" lang="El Código" onblur="buscar()" class="txt_mediano"/> 
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Nombre</td>
  <td>
  <input type="text" name="txtNombre" id="txtNombre" size="40" maxlength="60"value="" lang="El Nombre" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Dirección</td>
  <td>
  <input type="text" name="txtDireccion" id="txtDireccion" size="40" maxlength="60"value="" lang="La Dirección" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Teléfono</td>
  <td>
  <input type="text" name="txtTelefono" id="txtTelefono" size="40" maxlength="60"value="" lang="El Teléfono" class="txt_largo"/>
  </td>
</tr>


<tr>
  <td height="45" class="etiqueta">Correo</td>
  <td>
  <input type="text" name="txtCorreo" id="txtCorreo" size="40" maxlength="60"value="" lang="El Correo" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Contraseña</td>
  <td>
  <input type="password" name="txtClave" id="txtClave" size="40" maxlength="60"value="" lang="La Clave" class="txt_mediano"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Repita la Contraseña</td>
  <td>
  <input type="password" name="txtRepetir" id="txtRepetir" size="40" maxlength="60"value="" lang="Repita la Contraseña" class="txt_mediano"/>
  </td>
</tr>




  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="reset" name="cdmeliminar" id="cdmeliminar" value="Reset" onclick="" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='index.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
   <input id="txtModo" name="txtTipo" type="hidden"value="W" />
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
<script>

 seleccionarCombo('txtTipo','<?php echo $txtTipo?>')
 var sqlCodigo = 'select login, nombre from tbl_usuario where login like \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select login, nombre from tbl_usuario where nombre like \'%@parametro_descripcion%\'';
  
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;
	  
	 if (document.frmDatos.txtClave.value != document.frmDatos.txtRepetir.value)
	 {
		 alert('Las contraseñas deben ser iguales');
		 return false;
	 }   
    // if (!validarCorreo(document.frmDatos.txtCorreo.value))
	 //   return false;
	  

      document.frmDatos.action='registrar_usuarioweb.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='usuarios_web.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_usuario.php';  
	  document.frmDatos.submit();	  
   }
 </script>
<?php echo '</div>';
      echo '</div>';
?>
 
<?php
include("inc/pie.php");
?>