
<?php

include("includes/funciones.php");
include("inc/cabecera2.php");

$objconex=new mysqli(SERVIDOR,USUARIO,PASSWORD,NOMBREBD);

$resultado=$objconex->query("Select * from tbl_contenido");

echo' <div id="agrupar">';
 
  
  echo '<table align="center" height="100%" border="1" width="95%">';
echo '<tr>';
//echo '<td height="50" colspan="7" scope="col" border="0"></td>';
echo '</tr>';
echo '<tr align="center"><th>Titulo</th><th>Publicado en</th></tr>';

while($registro=$resultado->fetch_object()){
  
    echo '<tr align="center">';    
	//echo '<td >'.$registro->login. '</td>';
    echo '<td >'.$registro->titulo. '</td>';    
 
    echo '<td>'.$registro->fecha_inicio. '</td>';
	//echo '<td>'.$registro->fecha_exp. '</td>';
    echo "<td><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='ver' ></a></td>";
	//echo "<td border='3'><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='modificar' ></a></td>";
//	echo "<td border='3'><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='eliminar' ></a></td>";
    echo '</tr>';
	
  
   
}




 
  echo'</table>';
echo' </div>';
 include("inc/pie.php");
?>
