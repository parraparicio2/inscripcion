<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript">

function buscarRepresentante(){
    if($('#txtCodigoRepresentante').val()!= ""){
        
        $.ajax({
            type: "POST",
            url: "verificar_representante.php",
            data: "txtCodigoRepresentante="+$('#txtCodigoRepresentante').val(),
            beforeSend: function(){
            },
            success: function( respuesta ){
			var resultado = jQuery.parseJSON(respuesta);


              if(resultado.codigoRepresentante == '')
              {
				alert('Código del representante no registrado.');  
                document.frmDatos.txtCodigoRepresentante.value = '';
				document.getElementById('nombreRepresentante').innerHTML = '';
              }  
			  else
			  {
			    document.getElementById('nombreRepresentante').innerHTML = resultado.nombre;
			  } 
            }
        });
	}
}	

$(document).ready(function(){
//$('#txtCodigoRepresentante').focusout(buscarRepresentante); 
});
</script>


<title>Registro de Alumnos</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Registro nuevos Alumnos </div>
<?php

include("includes/funciones.php");
abrirSesion();
abrirSesionAdministrador();
$txtCodigo= "";
$txtCodigoRepresentante= "";
$txtNombre= "";
$txtNombreRepresentante= "";
$txtFechaNacimiento= "";
$txtTipoSangre= "";
$txtAlergico= "";
$txtLugarNacimiento="";
$txtEstado="";
$txtModo="I";
if(isset($_POST['txtCodigo'])&& trim($_POST['txtCodigo']<>""))
  {
     $sql="select a.*, b.nombre as nombre_representante from tbl_alumnos a left join tbl_representante b on a.codigo_representante = b.codigo_representante  where codigo_alumno ='".trim($_POST['txtCodigo'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['codigo_alumno'];
			  $txtCodigoRepresentante=$campo['codigo_representante'];
			  $txtNombreRepresentante=$campo['nombre_representante'];
			  $txtNombre=$campo['nombre'];
			  $txtFechaNacimiento=transformarFecha($campo['fecha_nacimiento']);
			  $txtTipoSangre=$campo['tipo_sangre'];
			  $txtAlergico = $campo['alergico'];
			  $txtLugarNacimiento = $campo['lugar_nacimiento'];
			  $txtEstado = $campo['estado'];
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Registro de Alumnos
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Código</td>
  <td width="348" >
  <input type="text" name="txtCodigo" id="txtCodigo" value="<?php echo $txtCodigo ?>" lang="El Código" onblur="buscar()" class="txt_mediano"/> 
  <input type ="button" onclick="abrirBusqueda('frmDatos', 'txtCodigo','busqueda.php',  sqlCodigo, sqlDescripcion, 1)" id="boton_browse" value ="..."/></td>
</tr>

<tr>
  <td height="45" class="etiqueta">Nombre</td>
  <td>
  <input type="text" name="txtNombre" id="txtNombre" size="40" maxlength="60"value="<?php echo $txtNombre ?>" lang="El Nombre" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Fecha Nacimiento</td>
  <td>
  <input type="text" name="txtFechaNacimiento" id="txtFechaNacimiento" size="40" maxlength="60"value="<?php echo $txtFechaNacimiento ?>" lang="La Fecha de Nacimiento" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Lugar de Nacimiento</td>
  <td>
  <input type="text" name="txtLugarNacimiento" id="txtLugarNacimiento" size="40" maxlength="60"value="<?php echo $txtLugarNacimiento ?>" lang="El Lugar de Nacimiento" class="txt_mediano"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Estado</td>
  <td>
  <input type="text" name="txtEstado" id="txtEstado" size="40" maxlength="60"value="<?php echo $txtEstado ?>" lang="El Estado" class="txt_mediano"/>
  </td>
</tr>


<tr>
  <td height="45" class="etiqueta">Tipo de Sangre</td>
  <td>
  <input type="text" name="txtTipoSangre" id="txtTipoSangre" size="40" maxlength="60"value="<?php echo $txtTipoSangre ?>" lang="El Tipo de Sangre" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Alergico a </td>
  <td>
  <input type="text" name="txtAlergico" id="txtAlergico" size="40" maxlength="60"value="<?php echo $txtAlergico ?>" lang="Sí es alergico" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Cédula del Representante</td>
  <td>
  <input type="text" name="txtCodigoRepresentante" id="txtCodigoRepresentante" value="<?php echo $txtCodigoRepresentante ?>" lang="El Representante" class="txt_mediano" onblur="buscarRepresentante()"/> <input type ="button" onclick="abrirBusqueda('frmDatos', 'txtCodigoRepresentante','busqueda.php',  sqlCodigoRepresentante, sqlDescripcionRepresentante, 1)" id="boton_browse" value ="..."/><span id ="nombreRepresentante" class ="etiqueta"><?php echo $txtNombreRepresentante ?></span>
  </td>
</tr>
  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cdmeliminar" id="cdmeliminar" value="Eliminar" onclick="botonEliminar()" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
<script>
 var sqlCodigo = 'select codigo_alumno, nombre from tbl_alumnos where codigo_alumno like \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select codigo_alumno, nombre from tbl_alumnos where nombre like \'%@parametro_descripcion%\'';
 var sqlCodigoRepresentante = 'select codigo_representante, nombre from tbl_representante where codigo_representante like \'%@parametro_codigo%\'';
 var sqlDescripcionRepresentante = 'select codigo_representante, nombre from tbl_representante where nombre like \'%@parametro_descripcion%\'';

   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'txtAlergico') )
        return false;
	  
	 if (validarFecha('txtFechaNacimiento') == false)
	    return false;	 
	  

      document.frmDatos.action='registrar_alumnos.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='alumnos.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_alumnos.php';  
	  document.frmDatos.submit();	   
   }
   
  Calendar.setup
  (
    {
      inputField     :    "txtFechaNacimiento",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
   
 </script>
 </div>
 </div>
</body>
</html>