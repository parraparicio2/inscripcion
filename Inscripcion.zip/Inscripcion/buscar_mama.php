<?php

  require_once("includes/funciones.php");
  
     $txtCedula = $_POST['txtCedulaM'];

	  $txtNombreM = "";
	  $txtTelefonoM = "";
	  $txtProfesionM = "";
	  $txtTrabajoM = "";
	  $txtFechaM = "";
	  $txtNacionalidadM = "";
	  
	  $txtCedulaP = "";
	  $txtNombreP = "";
	  $txtTelefonoP = "";
	  $txtProfesionP = "";
	  $txtTrabajoP = "";
	  $txtFechaP = "";
	  $txtNacionalidadP = "";

  $sql = "select * from vista_inscripcion where cedula_m = '".$txtCedula."'";
  $consulta = ejecutarConsulta($sql);
  if (mysqli_num_rows($consulta) > 0)
    {
      $campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);
	  $txtCedulaM = $campo['cedula_m'];
	  $txtNombreM = $campo['nombre_m'];
	  $txtTelefonoM = $campo['telefono_m'];
	  $txtProfesionM = $campo['profesion_m'];
	  $txtTrabajoM = $campo['trabajo_m'];
	  $txtFechaM = transformarFecha($campo['fecha_nac_m']);
	  $txtNacionalidadM = $campo['nacionalidad_m'];
	  
	  $txtCedulaP = $campo['cedula_p'];
	  $txtNombreP = $campo['nombre_p'];
	  $txtTelefonoP = $campo['telefono_p'];
	  $txtProfesionP = $campo['profesion_p'];
	  $txtTrabajoP = $campo['trabajo_p'];
	  $txtFechaP = transformarFecha($campo['fecha_nac_p']);
	  $txtNacionalidadP = $campo['nacionalidad_p'];
	  
	  
	}
	//$valores = array('cedula_m'=>$txtCedulaM,'nombre_m'=>$txtNombreM);
      $valores = array('cedula_m'=>$txtCedulaM,'nombre_m'=>$txtNombreM,'telefono_m'=>$txtTelefonoM,'profesion_m'=>$txtProfesionM,'trabajo_m'=>$txtTrabajoM,'fecha_nac_m'=>$txtFechaM,'nacionalidad_m'=>$txtNacionalidadM, 'cedula_p'=>$txtCedulaP,'nombre_p'=>$txtNombreP,'telefono_p'=>$txtTelefonoP,'profesion_p'=>$txtProfesionP,'trabajo_p'=>$txtTrabajoP,'fecha_nac_p'=>$txtFechaP,'nacionalidad_p'=>$txtNacionalidadP);							 
      echo json_encode($valores);	
	  
	 /*   $sql = "select codigo_representante, nombre from tbl_representante where codigo_representante = '". $_POST['txtCedulaM']."'";
  $consulta = ejecutarConsulta($sql);
  if (mysqli_num_rows($consulta) > 0)
    {
      $campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);
	  $txtCodigo = $campo['codigo_representante'];
	  $txtNombre = $campo['nombre'];
	}
      $valores = array('codigoRepresentante'=>$txtCodigo,'nombre'=>$txtNombre);							 
      echo json_encode($valores);	*/

	
?>
