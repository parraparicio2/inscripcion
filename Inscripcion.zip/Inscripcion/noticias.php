<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<title>Inscrición de Alumnos</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
<?php

include("includes/funciones.php");


//abrirSesion();
//abrirSesionAdministrador();

/*$sql="SELECT COALESCE(MAX(id_inscripcion),0) + 1 AS id_inscripcion FROM tbl_inscripcion";
$consulta=ejecutarConsulta($sql);
$campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);

$txtCodigo = $campo['id_inscripcion'];

$txtCodigoAlumno= "";
$txtNombre = "";
$txtCodigoSeccion= "";
$txtCodigoPeriodo= "";
$txtFecha = date("d/m/Y"); 
$txtEdad = ""; 
$txtModo="I";


if(isset($_POST['txtCodigoAlumno'])&& trim($_POST['txtCodigoAlumno']<>""))
  {
     $sql="select a.*, (YEAR(CURDATE())-YEAR(fecha_nacimiento)) - (RIGHT(CURDATE(),5)<RIGHT(fecha_nacimiento,5)) as edad from tbl_alumnos a where codigo_alumno ='".trim($_POST['txtCodigoAlumno'])."'";
	 $consulta=ejecutarConsulta($sql);
     if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigoAlumno=$campo['codigo_alumno'];
			  $txtNombre=$campo['nombre'];
			  $txtEdad=$campo['edad']." Años";
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Alumno no Registrado');</script>";
							 }
	}
 */



$objconex=new mysqli(SERVIDOR,USUARIO,PASSWORD,NOMBREBD);

$resultado=$objconex->query("Select * from tbl_contenido");


  echo '<div id="header_formulario">Inscripción de Alumnos</div>';
  
  echo '<table align="center" height="100%" border="0" width="100%">';
echo '<tr>';
echo '<td height="50" colspan="7" scope="col" border="0"></td>';
echo '</tr>';
echo '<tr align="center"><th>Autor</th><th>Titulo</th><th>fecha publicacion</th><th>fecha culminacion</th></tr>';

while($registro=$resultado->fetch_object()){
  
    echo '<tr align="center">';    
	echo '<td >'.$registro->login. '</td>';
    echo '<td >'.$registro->titulo. '</td>';    
 
    echo '<td>'.$registro->fecha_inicio. '</td>';
	echo '<td>'.$registro->fecha_exp. '</td>';
    echo "<td><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='ver' ></a></td>";
	echo "<td border='3'><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='modificar' ></a></td>";
	echo "<td border='3'><a href='detalle.php?detalle=". $registro->id_contenido."' ><input type='button' value='eliminar' ></a></td>";
    echo '</tr>';
	
  
   
}




 
  echo'</table>';
  echo '<table align="center">';

echo '<tr>';
echo '<td height="40" colspan="2" scope="col" border="0"></td>';
echo '</tr>';

echo "<tr><td><a href='form_noticias.php'><input type='button' name='cmdsalir' id='cmdsalir'           value='Nueva noticia' onclick='window.top.location='menu.php'' class='boton_comando'/></a></td>
          
 	  <td><a href='menu.php'><input type='button' name='cmdsalir' id='cmdsalir' value='Salir' onclick='window.top.location='menu.php'' class='boton_comando'/></a></td>
	
			  
       </tr>";
echo '</table>';

 echo'</div>
 </div>';
?>
</div>
 </div>
</body>
</html>