﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>
<LINK rel="stylesheet" href="css/tablas.css" type="text/css"/>
<title>Comprobante de Inscripción</title>
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>
</head>

<body>

<?php
 
include("includes/funciones.php");     
abrirSesion();

$txtCodigoSeccion=($_GET['codigo_seccion']);
$txtCodigoPeriodo=($_GET['codigo_periodo']);

   $sql = "select * from vista_inscripcion where codigo_seccion ='".$txtCodigoSeccion."' and codigo_periodo = '".$txtCodigoPeriodo."' order by nombre";
//  echo $sql;
  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		//  $nombre = $campo['nombre'];
	   }
	else
	{
	/* echo "<script> 
	          history.back();
			  alert('No se encuentra el registro'); 
	       </script>";*/
	   exit;   	   
	}
?>

<div id="contenedor">
   <div id="main">
        <div class="logo_reporte">   
           <img src="imagenes/logo_reportes.jpeg" style="height:100px">
        </div>
        <div class="titulo_reporte">Listado de Alumnos<img class='valign'></div>
        <div id="div_reporte_datos">
           <table>
              <tr>
                 <th>Sección:</th>
                 <td><?php echo $campo['codigo_seccion']." - ". $campo['descripcion_seccion'] ?></td>
              </tr>
              <tr>
                 <th>Período:</th>
                 <td><?php echo $campo['descripcion_periodo'] ?></td>
              </tr>
           </table>
        </div>
        <div id="div_reporte">
            <table id ="one-column-emphasis" >
                <tr>
                 <td>#</td>
                 <td style="width:700px">Nombre</td>
				
                </tr>
				
			
				
				 <?php
                $i=1;
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				 $id_inscripcion = $campo['id_inscripcion'];
                ?>
			
                  <tr>
                     <td ><?php echo $i++?> </td>
                     <td ><?php echo $campo['nombre']?></td>
					
             <td ><a href="reporte_inscripcion2.php?id_inscripcion=<?php echo $id_inscripcion?>">Ver...</a></td>
                  </tr>
                <?php 
                 }
                ?><?php echo $id_inscripcion?>
        
         	</table>
        </div>
    <div class="botones_reporte">
          <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
          <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class ="boton_comando"/>
    </div>

<script>
function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
}
</script>

  </div>
  </div>
</body>
</html>