function redondearBordes(objeto){
   $(this).ready( function(){
   $('.redondear').corner("");
	$('.redondear_categoria').corner("10px");
	$('.redondear_opcion').corner("20px");
	$('.borde_superior').corner("top 8px");
	$('.borde_inferior').corner("bottom 8px");
})
}
/************************************************************************/ 
function gradiente(id, desde, hasta, direccion, longitud, posicion ){
   if (longitud=='' && posicion =='') 	 
   {
		
		$(function() {
		
					$('#'+id).gradient({
						from:      desde,
						to:        hasta,
						direction: direccion
					});
				});
	}
	else
	{
		$(function() {
					$("#"+id+"'").gradient({
						from:      desde,
						to:        hasta,
						direction: direccion,
						length:    longitud,
						position:  posicion
					});
				});
	
	}
}
 


/************************************************************************/

