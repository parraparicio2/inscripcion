<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
 <link rel='stylesheet' type='text/css' href='css/principal.css'>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<title>Acceso</title>
</head>

<body>
<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Solo para personal Administrativo</div>
<?php
include("includes/funciones.php");

if(isset($_POST['txtLogin'])&& trim($_POST['txtLogin']<>""))
  {
     $sql="select * from tbl_usuario where login='".trim($_POST['txtLogin'])."' and clave = '".md5(trim($_POST['txtClave']))."'";
//	 echo $sql;
	 $consulta=ejecutarConsulta($sql);

	   if (mysqli_num_rows($consulta) > 0)
	   { 
		   while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  
			   session_start();
			   $_SESSION['login'] = $campo['login']; 
			   $_SESSION['tipo_usuario'] = $campo['tipo']; 
	
			   if ($_SESSION['tipo_usuario']=='W')
                   {
               echo "<script> alert('Acceso denegado');</script>";
			//   header("Location: menu.php");
		      }
			  if ($_SESSION['tipo_usuario']=='A')
                   {
               	     header("Location: menu.php");
		      }
			  
			  if ($_SESSION['tipo_usuario']=='U')
                   {
            
			   header("Location: menu.php");
		      }
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
			 }
	}
 
?>

<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario" style="width:400px">
  <div id="header_formulario">Acceso
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <td width="100" height="45" class="etiqueta">Usuario</td>
  <td width="500" ><input type="text" name="txtLogin" id="txtLogin"  class="txt_mediano" lang="El Usuario"/></td>
</tr>

<tr>
  <td height="45" class="etiqueta">Contraseña</td>
  <td><input type="password" name="txtClave" id="txtClave" class="txt_mediano" lang="la Contraseña"/></td>
</tr>

  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cmdguardar" id="cmdguardar" value="Aceptar" onclick="buscar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='index.php'" class="boton_comando"/>
     </div></td>
  </tr>
  </table>

</form>
<script>
  
   function buscar()
   {
	  if (validarDatos(document.frmDatos,'') )
         return false;
	  
	  document.frmDatos.action='login.php'; 
	  document.frmDatos.submit();
   }
 
   
 
 
</script>
</div>
</div>
</body>
</html>