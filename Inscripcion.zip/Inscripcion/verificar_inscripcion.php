<?php
  require_once("includes/funciones.php");
  $sql = "CALL sp_verificar_inscripcion('".$_POST['txtCodigoAlumno']."','".$_POST['txtCodigoSeccion']."','".$_POST['txtCodigoPeriodo']."')";
  $consulta = ejecutarConsulta($sql);
  $campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);
  $valores = array('valido'=>$campo['r_valido'],'mensaje'=>$campo['r_mensaje']);							 
  echo json_encode($valores);	
?>

