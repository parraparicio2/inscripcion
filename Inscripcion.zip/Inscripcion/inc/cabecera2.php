<!DOCTYPE HTML>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
    <head>



<script type="text/javascript" src="js/funciones.js"></script>
        <title>
            ..:: Loma linda ::..
        </title>
       <link rel='stylesheet' type='text/css' href='estilos/estilos.css'/>
       <link rel='stylesheet' type='text/css' href='css/principal.css'>
       <link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<LINK rel="stylesheet" href="estilos/tablas.css" type="text/css"/>

<style type="text/css">
a {
	color: #333;
}
#nav {
	margin: 0;
	padding: 7px 60px 0;
	line-height: 80%;
	width:85%;
	
	border-radius: 0;

	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	-o-border-radius: 0;
	-ms-border-radius: 0;
	
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
	-o-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
	-ms-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
background:-moz-linear-gradient(top, #096, #093 100%);
background:-webkit-linear-gradient(top, #096, #093 100%);
	background:-o-linear-gradient(top, #096, #093 100%);
	background:-ms-linear-gradient(top, #096, #093 100%);
/*	background: #096; /* for non-css3 browsers */
	

	/*border: solid 1px #6d6d6d;*/
}
#nav li {
	margin: 0 |px;
	padding: 0 0 8px;
	float: left;
	position: relative;
	list-style: none;
	font-family:Arial, Helvetica, sans-serif;
    padding-left:25px;
}
/* main level link */
#nav a {
	font-weight: bold;
	color:	#72C763; 
	
	text-decoration: none;
	display: block;
	padding:  8px 0px;
	margin: 0;
	border-radius: 1.6em;
	-webkit-border-radius: 1.6em;
	-moz-border-radius: 1.6em;
	-o-border-radius: 1.6em;
	text-shadow: 0 1px 1px rgba(0, 0, 0, .3);
}
/* main level link hover */
#nav .current a, #nav li:hover > a {
	background: #0C0; /* for non-css3 browsers */
	/*filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#ebebeb', endColorstr='#a1a1a1'); /* for IE */
	/*background: -webkit-gradient(linear, left top, left bottom, from(#ebebeb), to(#a1a1a1)); /* for webkit browsers */
	/*background: -moz-linear-gradient(top,  #ebebeb,  #a1a1a1); /* for firefox 3.6+ */

	color: #444;
	border-top: solid 1px #f8f8f8;
	-webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	-moz-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	-o-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	-ms-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	text-shadow: 0 1px 0 rgba(255, 255, 255, .8);
}
/* sub levels link hover */
#nav ul li:hover a, #nav li:hover li a {
	background: none;
	border: none;
	color: #666;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
	-o-box-shadow: none;
	-ms-box-shadow: none;
}
#nav ul a:hover {
background: #0C6 !important; /* for non-css3 browsers */
	/*filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#04acec', endColorstr='#0186ba'); /* for IE */
/*	/*background: -webkit-gradient(linear, left top, left bottom, from(#04acec), to(#0186ba)) !important; /* for webkit browsers */
	/*background: -moz-linear-gradient(top,  #04acec,  #0186ba) !important; /* for firefox 3.6+ */

	color: #FF3 !important;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	-o-border-radius: 0;
	-ms-border-radius: 0;
	text-shadow: 0 1px 1px rgba(0, 0, 0, .1);
}
/* level 2 list */
#nav ul {
	background: #CCC; /* fondo de la lista de despliegue*/
/*	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#cfcfcf'); /* for IE */
/*	background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#cfcfcf)); /* for webkit browsers */
/*	background: -moz-linear-gradient(top,  #fff,  #cfcfcf); /* for firefox 3.6+ */

	display: none;
	margin: 0;
	padding: 0;
	width: 185px;
	position: absolute;
	top: 35px;
	left: 0;
	border: solid 1px #b4b4b4;
	-webkit-border-radius: 15px;
	-moz-border-radius: 15px;
	-ms-border-radius: 15px;
	-o-border-radius: 15px;
	border-radius: 15px;
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	-ms-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	-o-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
}
/* dropdown */
#nav li:hover > ul {
	display: block;
}
#nav ul li {
	float: none;
	margin: 0;
	padding: 0;
}
#nav ul a {
	font-weight: normal;
	text-shadow: 0 1px 1px rgba(255, 255, 255, .9);
}
/* level 3+ list */
#nav ul ul {
	left: 181px;
	top: -3px;
}
/* rounded corners for first and last child */
#nav ul li:first-child > a {
	-webkit-border-top-left-radius: 9px;
	-moz-border-radius-top-left: 9px;
	-o-border-radius-top-left: 9px;
	-ms-border-radius-top-left: 9px;
	-webkit-border-top-right-radius: 9px;
	-moz-border-radius-top-right: 9px;
	-o-border-radius-top-right: 9px;
	-ms-border-radius-top-right: 9px;
}
#nav ul li:last-child > a {
	-webkit-border-bottom-left-radius: 9px;
	-moz-border-radius-bottom-left: 9px;
	-ms-border-radius-bottom-left: 9px;
	-o-border-radius-bottom-left: 9px;
	-webkit-border-bottom-right-radius: 9px;
	-moz-border-radius-bottom-right: 9px;
	-o-border-radius-bottom-right: 9px;
	-ms-border-radius-bottom-right: 9px;
	
}
/* clearfix */
#nav:after {
	content: ".";
	display: block;
	clear: both;
	visibility: hidden;
	line-height: 0;
	height: 0;

}
#nav {
	display: inline-block;
}
html[xmlns] #nav {
	display: block;
}
* html #nav {
	height: 1%;
}
  
</style>
	   
    </head>    


<body>


<div id="div_principal">


<div id='div_header'>

<div id='div_logo'>
<img src="./imagenes/logon.JPG" width="190" height="101">
</div>

<div id='div_fotos'>
<img src="./imagenes/Listo.gif" style="width:96%" height="101"> 
</div>
</div>


<div id='div_menu'>
<ul id="nav">
    
	<li><a href="index.php">Inicio</a><!--el boton principal-->
	
	</li>
		
	<li><a href="#">Preescolar</a>
		<ul>
            <li><a href="mision.php">vision y mision</a></li>
            
			<li><a href="instalaciones.php">instalaciones</a></li>
            <li><a href="preescolar.php">preescolar</a></li>
		</ul>
	</li>
	<li><a href="#">Actualidad</a>
		<ul>
			<li><a href="noticias2.php">noticias</a></li>
			
			
		</ul>
	</li>
	<li><a href="#">Equipo</a>
		<ul>
			<li><a href="logout.php">personal directivo</a></li>
			<li><a href="logout.php">personal docente</a></li>
			
			
		</ul>
	</li>

	<li><a href="preinscipcion.php">Pre-inscripcion</a>
		
	</li>
	
	<li><a href="#">Contancias</a>
		<ul>
			<li><a href="estudio.php">Contancia de estudio</a></li>
			<li><a href="carta.php">Carta de Conducta</a></li>
			
			
		</ul>
	</li>
	
    
    <li><a href="login.php">Intranet</a>
		
	</li>
	
    </li>
	
    <li><a href="usuarios_web.php">registrarse</a>
		
	</li>
	
</ul>

</div>

<div id='div_contenido'>



<div id='div_subcontenido'>


     
    
