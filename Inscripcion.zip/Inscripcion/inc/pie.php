

</div>
<div id='columna'> 
<div id='div_interes'>
<a class="twitter-timeline"  href="https://twitter.com/parrajpa"  data-widget-id="303689894721617921">Tweets por @parrajpa</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>





</div>
<div id='div_interes2'>
<img src="./imagenes/simoncito.JPG" width="150" height="250">
</div>
</div>
</div>
<div id='div_pie'>
<footer id="pie">
         <p><strong>Desarrollado para Preescolar Loma Linda, Maracaibo - Estado Zulia</strong></p>
      </footer>

</div>

</div>

</body>
</html>

