﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>
<LINK rel="stylesheet" href="css/tablas.css" type="text/css"/>
<title>Listado de Representantes</title>
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>
</head>

<body>

<?php
 
include("includes/funciones.php");
abrirSesion();
  $sql = "select * from vista_inscripcion where codigo_seccion ='".$_POST['txtCodigoSeccion']."' and codigo_periodo = '".$_POST['txtCodigoPeriodo']."' order by nombre_representante";
//  echo $sql;
  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		//  $nombre = $campo['nombre'];
	   }
	else
	{
	  echo "<script> 
	          history.back();
			  alert('No se encuentra el registro'); 
	       </script>";
	   exit;   	   
	}
?>

<div id="contenedor" >
   <div id="main"  style="width:900px">
<div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
        <div class="logo_reporte" style="padding:0px">   
           <img src="imagenes/logo_reportes.jpeg" style="height:100px">
        </div>
        <div class="titulo_reporte">Listado de Representantes</div>

        <div id="div_reporte_datos" style="padding:0px">
           <table>
              <tr>
                 <th>Sección:</th>
                 <td><?php echo $campo['codigo_seccion']." - ". $campo['descripcion_seccion'] ?></td>
              </tr>
              <tr>
                 <th>Período:</th>
                 <td><?php echo $campo['descripcion_periodo'] ?></td>
              </tr>
           </table>
        </div>
        <div id="div_reporte">
            <table id ="one-column-emphasis">
                <tr>
                 <td class ="etiqueta_reporte">#</td>
                 <td class ="etiqueta_reporte">Nombre</td>
                 <td class ="etiqueta_reporte">Alumno</td>
                 <td class ="etiqueta_reporte">Teléfono</td>
                 <td class ="etiqueta_reporte">Dirección</td>
                 <td class ="etiqueta_reporte">Correo</td>
                </tr>
				 <?php
                $i=1;
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
                ?>
                  <tr>
                     <td ><?php echo $i++?></td>
                     <td ><?php echo $campo['nombre_representante']?></td>
                     <td ><?php echo $campo['nombre']?></td>
                     <td ><?php echo $campo['telefono_representante']?></td>
                     <td ><?php echo $campo['direccion_representante']?></td>
                     <td ><?php echo $campo['correo_representante']?></td>
                    
                  </tr>
                <?php 
                 }
                ?>
        
         	</table>
        </div>
    <div class="botones_reporte">
          <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
          <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class ="boton_comando"/>
    </div>

<script>
function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
}
</script>

  </div>
  </div>
</body>
</html>