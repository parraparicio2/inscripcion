﻿

<?php
// SELECT * FROM tbl_contenido ORDER BY fecha_inicio DESC LIMIT 10 
include("includes/funciones.php");
include("inc/cabecera2.php");
//abrirSesion();
 $sql="select * from tbl_contenido";

  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		
	   }

?>

<div id="agrupar" style="overflow:auto;">
      
        
            <table id ="one-column-emphasis">
                <tr>
                 
                 <td class ="etiqueta_reporte" >Titulo de la noticia </td>
                 <td class ="etiqueta_reporte" style="width:10%">Publicada</td>
                 <td class ="etiqueta_reporte" style="width:15%">detalles</td>
                 
                </tr>
				 <?php
              $i=1;
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				 $id_contenido = $campo['id_contenido'];
                ?>
                  <tr>
                    
                     <td ><?php echo $campo['titulo']?></td>
                     <td ><?php echo transformarFecha($campo['fecha_inicio'])?></td>
                     <td ><a href="contenido_ver.php?id_contenido=<?php echo $id_contenido?>">Ver...</a></td>
                  </tr>
                <?php 
                 }
                ?>
        
         	</table>
        
		
</div>		
<?php
 
include("inc/pie.php");
?>
  
