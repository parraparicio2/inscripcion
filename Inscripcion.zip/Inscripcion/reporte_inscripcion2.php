﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>
<LINK rel="stylesheet" href="css/tablas.css" type="text/css"/>
<title>Comprobante de Inscripción</title>
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>
</head>

<body>
<div id="contenedor" style="width:100%; margin:0 auto">
   <div id="main" style="width:800px;" >


<?php
 
include("includes/funciones.php");
abrirSesion();


if (isset($_POST['txtCodigoInscripcion']))
   $idInscripcion = $_POST['txtCodigoInscripcion'];
   
if (isset($_GET['txtCodigoInscripcion']))
   $idInscripcion = $_GET['txtCodigoInscripcion'];
   

  $sql = "select * from vista_inscripcion where id_inscripcion  = '".$idInscripcion. "'";
  //echo $sql;
  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $nombre = $campo['nombre'];
		  $txtCodigoPeriodo = $campo['codigo_periodo'];
	   }
	else
	{
	  echo "<script> 
	          history.back();
			  alert('No se encuentra el registro'); 
	       </script>";
	   exit;   	 
	}
?>
<div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
<div class="logo_reporte"><img src="imagenes/logo_reportes.jpeg" style="height:100px" /></div>
<div class="titulo_reporte" style="padding:0px"><p>Comprobante de Inscripción</p><p><?php echo $campo['descripcion_periodo']?></p></div>
<div  id = "cuerpo" class = "renglon">
<!--table id ="one-column-emphasis" class = "tabla_reporte"-->
  <table id ="one-column-emphasis" class = "tabla_reporte">
    <tr>
     <td class ="etiqueta_reporte">Número</td>
     <td><?php echo $campo['id_inscripcion']?></td>
     <td class ="etiqueta_reporte">Fecha: </td>
     <td><?php echo transformarFecha($campo['fecha'])?></td>
    </tr>
  <tr>
    <td colspan="4" class ="etiqueta_reporte">Datos del Niño</td>
  </tr>

  <tr>
    <td class ="etiqueta_reporte">Código</td>
    <td><?php echo $campo['codigo_alumno']?></td>
    <td class ="etiqueta_reporte">Fecha Nac.</td>
    <td><?php echo transformarFecha($campo['fecha_nacimiento']) ?></td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Nombre</td>
    <td ><?php echo $campo['nombre']?></td>
    <td class ="etiqueta_reporte">Edad</td>
    <td><?php echo $campo['edad']?> Años</td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Alergico a</td>
    <td colspan="3"><?php echo $campo['alergico']?></td>
  </tr>  
  <tr>
    <td colspan="4" class ="etiqueta_reporte">Datos del transportista</td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Nombre</td>
    <td><?php echo $campo['transporte']?></td>
    <td class ="etiqueta_reporte">Telefono</td>
    <td><?php echo $campo['telefono_transporte']?></td>
  </tr>
  </tr>
    <tr>
    <td colspan="4" class ="etiqueta_reporte">Datos de la sección</td>
  </tr>
  <tr>
     <td class ="etiqueta_reporte">Sección</td>
     <td><?php echo $campo['codigo_seccion'] ." - " .$campo['descripcion_seccion']?></td>
     <td class ="etiqueta_reporte">Turno</td>
     <td><?php echo $campo['descripcion_turno']?></td>

  </tr>   
  <tr>
    <td colspan="4" class ="etiqueta_reporte">Datos del Representante</td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Nombre</td>
    <td><?php echo $campo['nombre_representante']?></td>
    <td class ="etiqueta_reporte">Teléfono</td>
    <td><?php echo $campo['telefono_representante']?></td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Dirección</td>
    <td colspan="3"><?php echo $campo['direccion_representante']?></td>
  </tr>
  <tr>
    <td colspan="4" class ="etiqueta_reporte">En Caso de Emergencia</td>
  </tr>
  <tr>
    <td class ="etiqueta_reporte">Llamar a</td>
    <td><?php echo $campo['emergencia']?></td>
    <td class ="etiqueta_reporte">Teléfono</td>
    <td><?php echo $campo['telefono_emergencia']?></td>
  </tr>
 </table>
</div>
<div class="botones_reporte">
      <?php  
		   if ($_SESSION['tipo_usuario']== 'A')
            echo "<input type='button' name='cmdEliminar' id='cmdEliminar' value='Eliminar' onclick='eliminar()' class ='boton_comando' />";
		?>
      <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
      <input type="button" value="Volver" onclick="volver()" id="cmdVolver" class ="boton_comando"/>
	  <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class ="boton_comando"/>
	  
      
</div>
<form id="frmDatos" name="frmDatos" method="post" action="">
   <input type = "hidden" id="txtCodigoInscripcion" name= "txtCodigoInscripcion" value = "<?php echo $idInscripcion ?>" /> 
   <input type = "hidden" id="txtCodigoSeccion" name= "txtCodigoSeccion" value = "<?php echo $campo['codigo_seccion'] ?>" /> 
   <input type = "hidden" id="txtCodigoPeriodo" name= "txtCodigoPeriodo" value = "<?php echo $txtCodigoPeriodo  ?>" />  
</form>

 
<script>
function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	mostrarBoton('cmdEliminar', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
	mostrarBoton('cmdEliminar', false);

}

function eliminar()
{
	document.forms[0].submit();
}

function volver()
{
    document.frmDatos.action = 'reporte_seccion.php';
 	document.frmDatos.submit();
}
</script>
  </div>
  </div>
</body>
</html>