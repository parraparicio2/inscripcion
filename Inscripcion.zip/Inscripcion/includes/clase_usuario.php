<?php 
require_once("funciones.php");    

class usuario{
	


public static function usuarioVerificar($login)
{ 
  $sql = "CALL sp_verificar_login('$login',@r_existe)";
  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_existe'];
}

public static function usuarioSesion($login, $password)
{ 
  $sql = "CALL sp_iniciar_sesion('$login','$password')";
  $result = ejecutarConsulta($sql);
  if ($result)
    { 
    $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
    return $campo;
	}
  else
     return false;	
}

public static function usuarioBuscar($id_usuario)
{ 
  $sql = "CALL sp_buscar_usuarios($id_usuario)";
  $result = ejecutarConsulta($sql);
  //echo $sql;
  if ($result)
    { 
    $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
    return $campo;
	}
  else
     return false;	
}


public static function listar_estados()
{	  
  $sql = "CALL sp_listar_estados(1)";
  $consulta = ejecutarConsulta($sql);
  return $consulta;
}

public static function usuarioRegistrar($login, $pass, $nombre, $correo, $telefono, $direccion, $fecha_nacimiento, $pregunta, $respuesta, $id_estado)
{
  $sql = "CALL sp_registrar_usuarios('$login', '$pass', '$nombre', '$correo', '$telefono', '$direccion', '$fecha_nacimiento', '$pregunta', '$respuesta', '$id_estado', @mensaje)";
  //echo $sql;
  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function usuarioActualizar($id_usuario, $nombre, $correo, $telefono, $direccion, $fecha_nacimiento, $id_estado)
{ 
  $sql = "CALL sp_actualizar_usuarios($id_usuario, '$nombre', '$correo', '$telefono', '$direccion', '$fecha_nacimiento', '$id_estado',@mensaje)";
  //echo $sql;

  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function usuarioSeguridad($id_usuario, $password, $pregunta, $respuesta)
{ 
  $sql = "CALL sp_cambiar_password($id_usuario, '$password','$pregunta', '$respuesta', @mensaje)";
  //echo $sql;

  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}

public static function usuarioBuscarPassword($id_usuario, $password)
{ 
  $sql = "CALL sp_buscar_password($id_usuario, '$password',@mensaje)";
  //echo $sql;

  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_valido'];
}

public static function usuarioBaja($id_usuario, $motivo)
{ 
  $sql = "CALL sp_baja_usuario($id_usuario, '$motivo',@mensaje)";
  //echo $sql;

  $result = ejecutarConsulta($sql);
  $campo = mysqli_fetch_array($result, MYSQLI_ASSOC);
  return $campo['r_mensaje'];
}


}//final de la clase
?>