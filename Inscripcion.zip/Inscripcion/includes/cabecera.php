<!DOCTYPE HTML>
<html>
    <head>
        <title>
            ..:: Noticias ::..
        </title>
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
    
        

    
       
    </head>
    
<body>
<div id="main">
 <!--<div id='div_main'>



  <!--<section id='contenido'>-->
    
