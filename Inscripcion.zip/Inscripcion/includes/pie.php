 </section>

<div id='div_footer'>

<footer>
    Copyright � 2012. Todos los derechos reservados. Recetascadadia.com �<br>
Powered by BUFU Blue NetWorks S.L.

<!--<input id="boton" type="button" value="" onClick="javascript:agregar();">-->

</footer>    

</div>
</div>
</body>
</html>
