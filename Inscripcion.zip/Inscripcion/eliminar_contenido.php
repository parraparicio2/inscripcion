<?php
include("includes/funciones.php");
abrirSesion();
	$sql="delete from tbl_contenido where id_contenido = '".$_GET['id_contenido']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";
?>
<script>
window.location = 'menu.php';
</script>