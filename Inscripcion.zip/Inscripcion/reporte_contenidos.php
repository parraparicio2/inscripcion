﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>
<LINK rel="stylesheet" href="css/tablas.css" type="text/css"/>
<title>Listado de cantenidos</title>
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>
</head>

<body>

<?php
 
include("includes/funciones.php");
abrirSesion();
 $sql="CALL sp_consulta_contenido('".formatoFecha($_POST['txtFechaInicio'])."', '".formatoFecha($_POST['txtFechaFin'])."')";

  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		
	   }
	else
	{
	  echo "<script> 
	          history.back();
			  alert('No se encuentra el registro'); 
	       </script>";
	   exit;   	   
	}
?>

<div id="contenedor" >
   <div id="main"  style="width:900px">
<div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
        <div class="logo_reporte" style="padding:0px">   
           <img src="imagenes/logo_reportes.jpeg" style="height:100px">
        </div>
        <div class="titulo_reporte">Listado de Contenidos</div>

       
        <div id="div_reporte">
            <table id ="one-column-emphasis">
                <tr>
                 <td class ="etiqueta_reporte">#</td>
                 <td class ="etiqueta_reporte">Titulo</td>
                 <td class ="etiqueta_reporte">Resumen</td>
                 <td class ="etiqueta_reporte">Fecha Inicio</td>
                 <td class ="etiqueta_reporte">Fecha Fin</td>
                 <td colspan ="4" class ="etiqueta_reporte">Operaciones</td>
                 
                </tr>
				 <?php
              $i=1;
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				 $id_contenido = $campo['id_contenido'];
                ?>
                  <tr>
                     <td ><?php echo $id_contenido ?></td>
                     <td ><?php echo $campo['titulo']?></td>
                     <td ><?php echo $campo['resumen']?></td>
                     <td ><?php echo transformarFecha($campo['fecha_inicio'])?></td>
                     <td ><?php echo transformarFecha($campo['fecha_exp'])?></td>
                     <td ><a href="contenido_ver.php?id_contenido=<?php echo $id_contenido?>">Ver...</a></td>
					 <?php  
                         if ($_SESSION['tipo_usuario']== 'A')
                         {
                     ?>
                          <td ><a href="contenidos.php?id_contenido=<?php echo $id_contenido?>">Modificar</a></td>
                          <td ><a href="eliminar_contenido.php?id_contenido=<?php echo $id_contenido?>">Eliminar</a></td>
                     <?php }?>
                  </tr>
                <?php 
                 }
                ?>
        
         	</table>
        </div>
    <div class="botones_reporte">
          <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
          <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class ="boton_comando"/>
    </div>

<script>
function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
}
</script>

  </div>
  </div>
</body>
</html>