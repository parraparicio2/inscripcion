<?php
include("includes/funciones.php");
abrirSesion();
	$sql="delete from tbl_inscripcion where id_inscripcion = '".$_POST['txtCodigoInscripcion']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";
?>
<script>
window.location = 'menu.php';
</script>