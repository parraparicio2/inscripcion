<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<title>Registro de Secciones</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Registro nuevas Secciones </div>
<?php

include("includes/funciones.php");
abrirSesion();
abrirSesionAdministrador();
$txtCodigo= "";
$txtDescripcion= "";
$txtCodigoTurno= "";
$txtCupos= "0";
$txtModo="I";
if(isset($_POST['txtCodigo'])&& trim($_POST['txtCodigo']<>""))
  {
     $sql="select * from tbl_seccion where codigo_seccion='".trim($_POST['txtCodigo'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['codigo_seccion'];
			  $txtCodigoTurno=$campo['codigo_turno'];
			  $txtDescripcion=$campo['descripcion'];
 			  $txtCupos=$campo['cupos'];
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Registro de Secciones
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Código</td>
  <td width="348" >
  <input type="text" name="txtCodigo" id="txtCodigo" value="<?php echo $txtCodigo ?>" lang="El Código" onblur="buscar()" class="txt_mediano"/> 
  <input type ="button" onclick="abrirBusqueda('frmDatos', 'txtCodigo','busqueda.php',  sqlCodigo, sqlDescripcion, 1)" id="boton_browse" value ="..." /></td>
</tr>

<tr>
  <td height="45" class="etiqueta">Descripción</td>
  <td>
  <input type="text" name="txtDescripcion" id="txtDescripcion" size="40" maxlength="60"value="<?php echo $txtDescripcion ?>" lang="La Descripción" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Turno</td>
  <td>
     <select style=" width:150px " name="txtCodigoTurno" id="txtCodigoTurno" >
       <?php 
	   $sql = "select * from tbl_turno";
	   $consulta=ejecutarConsulta($sql);
       while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
         {
		 ?>
		 <option value='<?php echo $campo['codigo_turno'];?>'><?php echo $campo['descripcion'];?></option>
         <?php    
         }   
         ?>
     </select>  
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Cupos</td>
  <td>
  <input type="text" name="txtCupos" id="txtCupos" size="40" maxlength="60"value="<?php echo $txtCupos ?>" lang="El Cupo" class="txt_mediano" onkeypress="return soloNumeros(event)"/>
  </td>
</tr>


  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cdmeliminar" id="cdmeliminar" value="Eliminar" onclick="botonEliminar()" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
<script>
  seleccionarCombo('txtCodigoTurno','<?php echo $txtCodigoTurno?>')

 var sqlCodigo = 'select codigo_seccion, descripcion from tbl_seccion where codigo_seccion like \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select codigo_seccion, descripcion from tbl_seccion where descripcion like \'%@parametro_descripcion%\'';
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;
	   
      document.frmDatos.action='registrar_seccion.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='seccion.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_seccion.php';  
	  document.frmDatos.submit();	  
   }
 </script>
 </div>
 </div>
</body>
</html>