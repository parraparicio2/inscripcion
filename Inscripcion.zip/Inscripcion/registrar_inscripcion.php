<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Registro de Inscripcion</title>
 

</head>

<html>
<body>
<form method="post" action="reporte_inscripcion.php">

<?php
include("includes/funciones.php");
abrirSesion();
$login = $_SESSION['login'];
if ($_POST['txtModo']!="E")
{
	$sql="CALL sp_inscripcion('".$_POST['txtPreinscripcion']."','".$_POST['txtCodigoPeriodo']."','".$_POST['txtCodigoSeccion']."','".$_POST['txtCodigoAlumno']."','".$login."','".formatoFecha($_POST['txtFecha'])."','".$_POST['txtEmergencia']."','".$_POST['txtTelefonoEmergencia']."','".$_POST['txtTransporte']."','".$_POST['txtTelefonoTransporte']."','".$_POST['cbHermano']."','".$_POST['txtCodigoSeccionHermano']."','".$_POST['cbSeguro']."','".$_POST['txtNombreSeguro']."','".$_POST['txtTelefonoSeguro']."','".$_POST['txtClave']."','".$_POST['txtCedulaM']."','".$_POST['txtNombreM']."','".$_POST['txtTelefonoM']."','".$_POST['txtProfesionM']."','".$_POST['txtTrabajoM']."','".$_POST['txtCedulaP']."','".$_POST['txtNombreP']."','".$_POST['txtTelefonoP']."','".$_POST['txtProfesionP']."','".$_POST['txtTrabajoP']."','".formatoFecha($_POST['txtFechaM'])."','".formatoFecha($_POST['txtFechaP'])."','".$_POST['txtNacionalidadM']."','".$_POST['txtNacionalidadP']."')";
	//echo $sql;
	$consulta=ejecutarConsulta($sql);
	$campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
	
	echo "<input type='hidden' id = 'txtCodigoInscripcion' name = 'txtCodigoInscripcion' value='". $campo['r_id_inscripcion']."'>"; 
	echo "<script>alert('Registro Guardado')
          document.forms[0].submit();
		  </script>";


}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_inscripcion where id_inscripcion  = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";
}
//echo $sql;	

?>
<script>
//window.location = 'inscripcion.php';
</script>
</form>

</body>
</html>

