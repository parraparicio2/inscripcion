<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<title>Listado de Alumnos</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Listado de Alumnos por Secciones </div>
<?php

include("includes/funciones.php");
//abrirSesion();
//abrirSesionAdministrador();


?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Listado de Alumnos
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Sección</td>
  <td>
     <select class="combo_largo" name="txtCodigoSeccion" id="txtCodigoSeccion" >
       <?php 
	   $sql = "select * from tbl_seccion";
	   $consulta=ejecutarConsulta($sql);
       while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
         {
		 ?>
		 <option value='<?php echo $campo['codigo_seccion'];?>'><?php echo $campo['descripcion'];?></option>
         <?php    
         }   
         ?>
     </select>  
  </td>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Periodo</td>
  <td>
     <select class="combo_largo" name="txtCodigoPeriodo" id="txtCodigoPeriodo" >
       <?php 
	   $sql = "select * from tbl_periodo";
	   $consulta=ejecutarConsulta($sql);
       while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
         {
		 ?>
		 <option value='<?php echo $campo['codigo_periodo'];?>'><?php echo $campo['descripcion'];?></option>
         <?php    
         }   
         ?>
     </select>  
  </td>
</tr>

  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cmdguardar" id="cmdguardar" value="Aceptar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
</form>
<script>
 seleccionarCombo('txtCodigoPeriodo','<?php echo periodoActual()?>')
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;

      document.frmDatos.action='reporte_seccion.php';  
	  document.frmDatos.submit();
	  
   }
 </script>
 </div>
 </div>
</body>
</html>