﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<title>Registro de Representantes</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Registro de nuevos Representantes </div>
<?php

include("includes/funciones.php");
abrirSesion();
abrirSesionAdministrador();
$txtCodigo= "";
$txtNombre= "";
$txtDireccion= "";
$txtConyugue= "";
$txtCorreo= "";
$txtTelefono= "";
$txtModo="I";
if(isset($_POST['txtCodigo'])&& trim($_POST['txtCodigo']<>""))
  {
     $sql="select * from tbl_representante where codigo_representante ='".trim($_POST['txtCodigo'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['codigo_representante'];
			  $txtNombre=$campo['nombre'];
			  $txtConyugue=$campo['conyugue'];
			  $txtDireccion=$campo['direccion'];
			  $txtTelefono=$campo['telefono'];
			  $txtCorreo=$campo['correo'];
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Registro de Representantes
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Cedula</td>
  <td width="348" >
  <input type="text" name="txtCodigo" id="txtCodigo" value="<?php echo $txtCodigo ?>" lang="El Código" onblur="buscar()" class="txt_mediano"/> 
  <input type ="button" onclick="abrirBusqueda('frmDatos', 'txtCodigo','busqueda.php',  sqlCodigo, sqlDescripcion, 1)" id="boton_browse" value ="..." /></td>
</tr>

<tr>
  <td height="45" class="etiqueta">Nombre</td>
  <td>
  <input type="text" name="txtNombre" id="txtNombre" size="40" maxlength="60"value="<?php echo $txtNombre ?>" lang="El Nombre" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Dirección</td>
  <td>
  <input type="text" name="txtDireccion" id="txtDireccion" size="40" maxlength="60"value="<?php echo $txtDireccion ?>" lang="La Dirección" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Teléfono</td>
  <td>
  <input type="text" name="txtTelefono" id="txtTelefono" size="40" maxlength="60"value="<?php echo $txtTelefono ?>" lang="El Teléfono" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Correo</td>
  <td>
  <input type="text" name="txtCorreo" id="txtCorreo" size="40" maxlength="60"value="<?php echo $txtCorreo ?>" lang="El Correo" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Conyugue</td>
  <td>
  <input type="text" name="txtConyugue" id="txtConyugue" size="40" maxlength="60"value="<?php echo $txtConyugue ?>" lang="El Conyugue" class="txt_largo"/>
  </td>
</tr>


  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cdmeliminar" id="cdmeliminar" value="Eliminar" onclick="botonEliminar()" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
<script>
 var sqlCodigo = 'select codigo_representante, nombre from tbl_representante where codigo_representante like \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select codigo_representante, nombre from tbl_representante where nombre like \'%@parametro_descripcion%\'';
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;
	  
    // if (!validarCorreo(document.frmDatos.txtCorreo.value))
	 //   return false;
	  

      document.frmDatos.action='registrar_representante.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='representante.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_representante.php';  
	  document.frmDatos.submit();	  
   }
 </script>
 </div>
 </div>
</body>
</html>