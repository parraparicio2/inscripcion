/*
SQLyog Ultimate v9.02 
MySQL - 5.5.20-log : Database - bdinscripcion
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdinscripcion` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bdinscripcion`;

/*Table structure for table `tbl_alumnos` */

DROP TABLE IF EXISTS `tbl_alumnos`;

CREATE TABLE `tbl_alumnos` (
  `codigo_alumno` varchar(15) NOT NULL,
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `tipo_sangre` varchar(15) DEFAULT NULL,
  `alergico` text,
  PRIMARY KEY (`codigo_alumno`),
  KEY `codigo_representante` (`codigo_representante`),
  CONSTRAINT `tbl_alumnos_ibfk_1` FOREIGN KEY (`codigo_representante`) REFERENCES `tbl_representante` (`codigo_representante`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_alumnos` */

LOCK TABLES `tbl_alumnos` WRITE;

insert  into `tbl_alumnos`(`codigo_alumno`,`codigo_representante`,`nombre`,`fecha_nacimiento`,`tipo_sangre`,`alergico`) values ('1','16459131','Carla Adelí Parra Pérez','2009-12-11','o positivo','nada '),('2','16459131','salvador parra','2011-10-17','as','nada ');

UNLOCK TABLES;

/*Table structure for table `tbl_inscripcion` */

DROP TABLE IF EXISTS `tbl_inscripcion`;

CREATE TABLE `tbl_inscripcion` (
  `id_inscripcion` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_periodo` varchar(15) NOT NULL,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_alumno` varchar(15) NOT NULL,
  `login` varchar(20) NOT NULL,
  `fecha` date DEFAULT NULL,
  `emergencia` varchar(100) DEFAULT NULL,
  `telefono_emergencia` varchar(40) DEFAULT NULL,
  `transporte` varchar(50) DEFAULT NULL,
  `telefono_transporte` varchar(40) DEFAULT NULL,
  `hermanos` tinyint(1) DEFAULT '0',
  `codigo_seccion_hermano` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id_inscripcion`),
  KEY `codigo_periodo` (`codigo_periodo`),
  KEY `codigo_alumno` (`codigo_alumno`),
  KEY `codigo_seccion` (`codigo_seccion`),
  KEY `login` (`login`),
  CONSTRAINT `tbl_inscripcion_ibfk_1` FOREIGN KEY (`codigo_periodo`) REFERENCES `tbl_periodo` (`codigo_periodo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_2` FOREIGN KEY (`codigo_alumno`) REFERENCES `tbl_alumnos` (`codigo_alumno`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_3` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_4` FOREIGN KEY (`login`) REFERENCES `tbl_usuario` (`login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_inscripcion` */

LOCK TABLES `tbl_inscripcion` WRITE;

insert  into `tbl_inscripcion`(`id_inscripcion`,`codigo_periodo`,`codigo_seccion`,`codigo_alumno`,`login`,`fecha`,`emergencia`,`telefono_emergencia`,`transporte`,`telefono_transporte`,`hermanos`,`codigo_seccion_hermano`) values (59,'02','02','1','1','2012-11-05','erw','werw','wrw','werwerw',0,'werw'),(60,'02','02','2','1','2012-11-05','gabriel parra','123123','12312','21312',1,'en la merma');

UNLOCK TABLES;

/*Table structure for table `tbl_maestros` */

DROP TABLE IF EXISTS `tbl_maestros`;

CREATE TABLE `tbl_maestros` (
  `codigo_maestro` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_maestro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_maestros` */

LOCK TABLES `tbl_maestros` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_periodo` */

DROP TABLE IF EXISTS `tbl_periodo`;

CREATE TABLE `tbl_periodo` (
  `codigo_periodo` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `periodo_actual` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codigo_periodo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_periodo` */

LOCK TABLES `tbl_periodo` WRITE;

insert  into `tbl_periodo`(`codigo_periodo`,`descripcion`,`periodo_actual`) values ('01','Período Escolar 2010 - 2011',0),('02','Periodo Escolar 2012-2013',1);

UNLOCK TABLES;

/*Table structure for table `tbl_representante` */

DROP TABLE IF EXISTS `tbl_representante`;

CREATE TABLE `tbl_representante` (
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `conyugue` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_representante`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_representante` */

LOCK TABLES `tbl_representante` WRITE;

insert  into `tbl_representante`(`codigo_representante`,`nombre`,`telefono`,`direccion`,`conyugue`,`correo`) values ('15287193','Ariani Perez','1231','su casa','carlos parra','aribracho@hotmail.com'),('16459131','carlos parra','12312','residencias gallo verde , apartamento 12, edificio b-3','asssssssssssss','sss');

UNLOCK TABLES;

/*Table structure for table `tbl_seccion` */

DROP TABLE IF EXISTS `tbl_seccion`;

CREATE TABLE `tbl_seccion` (
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cupos` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo_seccion`),
  KEY `codigo_turno` (`codigo_turno`),
  CONSTRAINT `tbl_seccion_ibfk_1` FOREIGN KEY (`codigo_turno`) REFERENCES `tbl_turno` (`codigo_turno`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion` */

LOCK TABLES `tbl_seccion` WRITE;

insert  into `tbl_seccion`(`codigo_seccion`,`codigo_turno`,`descripcion`,`cupos`) values ('02','01','sala de 5 años',50),('1','03','sala de 3 años',60);

UNLOCK TABLES;

/*Table structure for table `tbl_seccion_maestros` */

DROP TABLE IF EXISTS `tbl_seccion_maestros`;

CREATE TABLE `tbl_seccion_maestros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_maestro` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_maestro` (`codigo_maestro`),
  KEY `codigo_seccion` (`codigo_seccion`),
  CONSTRAINT `tbl_seccion_maestros_ibfk_1` FOREIGN KEY (`codigo_maestro`) REFERENCES `tbl_maestros` (`codigo_maestro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_seccion_maestros_ibfk_2` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion_maestros` */

LOCK TABLES `tbl_seccion_maestros` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_turno` */

DROP TABLE IF EXISTS `tbl_turno`;

CREATE TABLE `tbl_turno` (
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_turno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_turno` */

LOCK TABLES `tbl_turno` WRITE;

insert  into `tbl_turno`(`codigo_turno`,`descripcion`) values ('01','Tarde'),('03','noche');

UNLOCK TABLES;

/*Table structure for table `tbl_usuario` */

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `login` varchar(20) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_usuario` */

LOCK TABLES `tbl_usuario` WRITE;

insert  into `tbl_usuario`(`login`,`nombre`,`correo`,`telefono`,`direccion`,`clave`,`tipo`,`fecha`) values ('1','Carlos Parra','sdfs','dfsfsd','sdfsd','c4ca4238a0b923820dcc509a6f75849b','A','2012-11-04'),('3','3','3','3','3','eccbc87e4b5ce2fe28308fd9f2a7baf3','U','2012-11-04'),('admin','Javier Parra','parraparicio@yahoo.com','1','1','c81e728d9d4c2f636f067f89cc14862c','A','0000-00-00');

UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
