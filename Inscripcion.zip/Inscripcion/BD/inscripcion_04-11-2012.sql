/*
SQLyog Ultimate v9.02 
MySQL - 5.5.16-log : Database - bdinscripcion
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdinscripcion` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bdinscripcion`;

/*Table structure for table `tbl_alumnos` */

DROP TABLE IF EXISTS `tbl_alumnos`;

CREATE TABLE `tbl_alumnos` (
  `codigo_alumno` varchar(15) NOT NULL,
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `tipo_sangre` varchar(15) DEFAULT NULL,
  `alergico` text,
  PRIMARY KEY (`codigo_alumno`),
  KEY `codigo_representante` (`codigo_representante`),
  CONSTRAINT `tbl_alumnos_ibfk_1` FOREIGN KEY (`codigo_representante`) REFERENCES `tbl_representante` (`codigo_representante`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_alumnos` */

insert  into `tbl_alumnos`(`codigo_alumno`,`codigo_representante`,`nombre`,`fecha_nacimiento`,`tipo_sangre`,`alergico`) values ('1','16459131','Carla Adelí Parra Pérez','2009-12-11','asda',NULL),('2','16459131','salvador parra','2011-10-17','as',NULL);

/*Table structure for table `tbl_inscripcion` */

DROP TABLE IF EXISTS `tbl_inscripcion`;

CREATE TABLE `tbl_inscripcion` (
  `id_inscripcion` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_periodo` varchar(15) NOT NULL,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_alumno` varchar(15) NOT NULL,
  `login` varchar(20) NOT NULL,
  `fecha` date DEFAULT NULL,
  `emergencia` varchar(100) DEFAULT NULL,
  `telefono_emergencia` varchar(40) DEFAULT NULL,
  `transporte` varchar(50) DEFAULT NULL,
  `telefono_transporte` varchar(40) DEFAULT NULL,
  `hermanos` tinyint(1) DEFAULT NULL,
  `codigo_seccion_hermano` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id_inscripcion`),
  KEY `codigo_periodo` (`codigo_periodo`),
  KEY `codigo_alumno` (`codigo_alumno`),
  KEY `codigo_seccion` (`codigo_seccion`),
  KEY `login` (`login`),
  CONSTRAINT `tbl_inscripcion_ibfk_1` FOREIGN KEY (`codigo_periodo`) REFERENCES `tbl_periodo` (`codigo_periodo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_2` FOREIGN KEY (`codigo_alumno`) REFERENCES `tbl_alumnos` (`codigo_alumno`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_3` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_4` FOREIGN KEY (`login`) REFERENCES `tbl_usuario` (`login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_inscripcion` */

insert  into `tbl_inscripcion`(`id_inscripcion`,`codigo_periodo`,`codigo_seccion`,`codigo_alumno`,`login`,`fecha`,`emergencia`,`telefono_emergencia`,`transporte`,`telefono_transporte`,`hermanos`,`codigo_seccion_hermano`) values (53,'02','1','2','admin','2012-10-23',NULL,NULL,NULL,NULL,NULL,NULL),(54,'01','02','1','admin','2012-10-23',NULL,NULL,NULL,NULL,NULL,NULL),(55,'02','1','1','admin','2012-10-23',NULL,NULL,NULL,NULL,NULL,NULL),(56,'02','02','1','admin','2012-10-23',NULL,NULL,NULL,NULL,NULL,NULL),(57,'02','02','2','1','2012-11-05',NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `tbl_maestros` */

DROP TABLE IF EXISTS `tbl_maestros`;

CREATE TABLE `tbl_maestros` (
  `codigo_maestro` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_maestro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_maestros` */

/*Table structure for table `tbl_periodo` */

DROP TABLE IF EXISTS `tbl_periodo`;

CREATE TABLE `tbl_periodo` (
  `codigo_periodo` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `periodo_actual` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codigo_periodo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_periodo` */

insert  into `tbl_periodo`(`codigo_periodo`,`descripcion`,`periodo_actual`) values ('01','Período Escolar 2010 - 2011',0),('02','Periodo Escolar 2012-2013',1);

/*Table structure for table `tbl_representante` */

DROP TABLE IF EXISTS `tbl_representante`;

CREATE TABLE `tbl_representante` (
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `conyugue` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_representante`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_representante` */

insert  into `tbl_representante`(`codigo_representante`,`nombre`,`telefono`,`direccion`,`conyugue`,`correo`) values ('15287193','Ariani Perez','1231','su casa','carlos parra','aribracho@hotmail.com'),('16459131','carlos parra','12312','residencias gallo verde , apartamento 12, edificio b-3','asssssssssssss','sss');

/*Table structure for table `tbl_seccion` */

DROP TABLE IF EXISTS `tbl_seccion`;

CREATE TABLE `tbl_seccion` (
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `cupos` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo_seccion`),
  KEY `codigo_turno` (`codigo_turno`),
  CONSTRAINT `tbl_seccion_ibfk_1` FOREIGN KEY (`codigo_turno`) REFERENCES `tbl_turno` (`codigo_turno`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion` */

insert  into `tbl_seccion`(`codigo_seccion`,`codigo_turno`,`descripcion`,`cupos`) values ('02','01','sala de 5 años',50),('1','03','sala de 3 años',2);

/*Table structure for table `tbl_seccion_maestros` */

DROP TABLE IF EXISTS `tbl_seccion_maestros`;

CREATE TABLE `tbl_seccion_maestros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_maestro` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_maestro` (`codigo_maestro`),
  KEY `codigo_seccion` (`codigo_seccion`),
  CONSTRAINT `tbl_seccion_maestros_ibfk_1` FOREIGN KEY (`codigo_maestro`) REFERENCES `tbl_maestros` (`codigo_maestro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_seccion_maestros_ibfk_2` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion_maestros` */

/*Table structure for table `tbl_turno` */

DROP TABLE IF EXISTS `tbl_turno`;

CREATE TABLE `tbl_turno` (
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_turno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_turno` */

insert  into `tbl_turno`(`codigo_turno`,`descripcion`) values ('01','Tarde'),('03','noche');

/*Table structure for table `tbl_usuario` */

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `login` varchar(20) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_usuario` */

insert  into `tbl_usuario`(`login`,`nombre`,`correo`,`telefono`,`direccion`,`clave`,`tipo`,`fecha`) values ('1','Carlos Parra','sdfs','dfsfsd','sdfsd','c4ca4238a0b923820dcc509a6f75849b','A','2012-11-04'),('3','3','3','3','3','eccbc87e4b5ce2fe28308fd9f2a7baf3','U','2012-11-04'),('admin','Javier Parra','parraparicio@yahoo.com','1','1','c81e728d9d4c2f636f067f89cc14862c','A','0000-00-00');

/* Procedure structure for procedure `sp_alumnos` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_alumnos` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_alumnos`(
  p_codigo_alumno VARCHAR(15),
  p_codigo_representante VARCHAR(15),
  p_nombre VARCHAR(60),
  p_fecha_nacimiento date,
  p_tipo_sangre VARCHAR(150)
)
BEGIN
       INSERT INTO tbl_alumnos
                   (
                   codigo_alumno, 
                   codigo_representante,
                   nombre,
                   fecha_nacimiento,
                   tipo_sangre
                   )
            VALUES (
                   p_codigo_alumno, 
                   p_codigo_representante,
                   p_nombre,
                   p_fecha_nacimiento,
                   p_tipo_sangre
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  codigo_alumno = p_codigo_alumno, 
                   codigo_representante = p_codigo_representante,
                   nombre = p_nombre,
                   fecha_nacimiento = p_fecha_nacimiento,
                   tipo_sangre = p_tipo_sangre;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_inscripcion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_inscripcion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_inscripcion`(
   
   p_codigo_periodo varchar(15),
   p_codigo_seccion varchar(15),
   p_codigo_alumno varchar(15),
   p_login varchar(20),
   p_fecha date 
)
BEGIN
declare r_id_inscripcion bigint;
    
           INSERT INTO tbl_inscripcion
                   (
                   codigo_periodo, 
                   codigo_seccion, 
                   codigo_alumno, 
                   login,
                   fecha
                   )
            VALUES (
                   p_codigo_periodo,
                   p_codigo_seccion,  
                   p_codigo_alumno, 
                   p_login,
                   p_fecha
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  codigo_periodo = p_codigo_periodo,
                   codigo_seccion = p_codigo_seccion,  
                   codigo_alumno = p_codigo_alumno, 
                   login = p_login,
                   fecha = p_fecha;
                   
   
      set r_id_inscripcion = LAST_INSERT_ID();
      select r_id_inscripcion;
   
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_maestros` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_maestros` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_maestros`(
  p_codigo_maestro VARCHAR(15),
  p_nombre VARCHAR(60),
  p_telefono VARCHAR(40),
  p_direccion VARCHAR(150),
  p_correo VARCHAR(40)
)
BEGIN
       INSERT INTO tbl_maestros
                   (
                   codigo_maestro,
                   nombre,
                   telefono,
                   direccion,
                   correo)
            VALUES (
                   p_codigo_representante,
                   p_nombre,
                   p_telefono,
                   p_direccion,
                   p_correo
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  nombre = p_nombre,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   correo = p_correo;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_periodos` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_periodos` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_periodos`(
   p_codigo_periodo varchar(15),
   p_descripcion varchar(160),
   p_periodo_actual bool
)
BEGIN
    
      INSERT INTO tbl_periodo
                   (
                   codigo_periodo,
                   descripcion,
                   periodo_actual
                   )
            VALUES (
                    p_codigo_periodo,
                    p_descripcion,
                    p_periodo_actual
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion,
                  periodo_actual = p_periodo_actual;         
                  
        if p_periodo_actual = 1 then
           update tbl_periodo 
              set periodo_actual = 0
            where codigo_periodo <> p_codigo_periodo;   
        end if;          
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_representante` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_representante` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_representante`(
  p_codigo_representante varchar(15),
  p_nombre varchar(60),
  p_telefono varchar(40),
  p_direccion varchar(150),
  p_conyugue varchar(100),
  p_correo varchar(40)
)
BEGIN
       INSERT INTO tbl_representante
                   (
                   codigo_representante,
                   nombre,
                   telefono,
                   direccion,
                   conyugue,
                   correo)
            VALUES (
                   p_codigo_representante,
                   p_nombre,
                   p_telefono,
                   p_direccion,
                   p_conyugue,
                   p_correo
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  nombre = p_nombre,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   conyugue = p_conyugue,
                   correo = p_correo;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_seccion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_seccion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_seccion`(
  p_codigo_seccion varchar(15),
  p_codigo_turno varchar(15),
  p_descripcion varchar(160),
  p_cupos int
  
)
BEGIN
       INSERT INTO tbl_seccion
                   (
                   codigo_seccion,
                   codigo_turno,
                   descripcion,
                   cupos
                   )
            VALUES (
                    p_codigo_seccion,
                    p_codigo_turno,
                    p_descripcion,
                    p_cupos
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion,
                  codigo_turno = p_codigo_turno,
                  cupos = p_cupos;      
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_turno` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_turno` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_turno`(
   p_codigo_turno varchar(15),
   p_descripcion varchar(60)
)
BEGIN
       INSERT INTO tbl_turno
                   (
                   codigo_turno,
                   descripcion)
            VALUES (
                    p_codigo_turno,
                    p_descripcion
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion;          
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_usuario` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_usuario` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_usuario`(
  p_login VARCHAR(15),
  p_nombre VARCHAR(60),
  p_correo varchar(40),
  p_telefono VARCHAR(40),
  p_direccion varchar(100),
  p_clave varchar(100),
  p_tipo varchar(10)
)
BEGIN
       INSERT INTO tbl_usuario
                   (
                   login, 
                   nombre,
                   correo,
                   telefono,
                   direccion,
                   clave,
                   tipo,
                   fecha
                   
                   )
            VALUES (
                   p_login, 
                   p_nombre,
                   p_correo,
                   p_telefono,
                   p_direccion,
                   md5(p_clave),
                   p_tipo,
                   current_date
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  login = p_login, 
                   nombre = p_nombre,
                   correo = p_correo,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   clave = md5(p_clave),
                   tipo = p_tipo;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `sp_verificar_inscripcion` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_verificar_inscripcion` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_verificar_inscripcion`(
   p_codigo_alumno varchar(15),
   p_codigo_seccion varchar(15),
   p_codigo_periodo varchar(15)
)
BEGIN
    declare v_contador integer;
    declare r_mensaje varchar(100); 
    declare r_valido bool;
    declare v_cupos integer;
    
	 SET r_mensaje = '';
	 SET r_valido = 1;
       SELECT COUNT(*) 
         into v_contador 
         FROM tbl_inscripcion 
        WHERE codigo_alumno = p_codigo_alumno 
          AND codigo_seccion = p_codigo_seccion
          and codigo_periodo = p_codigo_periodo;
         
       if (v_contador > 0) then
          set r_mensaje = 'El Alumno ya ha sido inscrito en este periodo escolar';
          set r_valido = 0;
       end if;
       
		  SELECT (SELECT COALESCE(cupos,0) FROM tbl_seccion WHERE codigo_seccion = p_codigo_seccion) - COALESCE(COUNT(*),0)   
			   into v_cupos 
				FROM tbl_inscripcion 
			  WHERE codigo_seccion = p_codigo_seccion 
				 AND codigo_periodo = p_codigo_periodo;
				 
				 if (v_cupos <= 0) then
					 SET r_mensaje = 'Ya no hay cupos en esta sección intente en otra';
					 SET r_valido = 0;
				 end if;  
				 
           
       SELECT r_mensaje, r_valido;
    END */$$
DELIMITER ;

/*Table structure for table `vista_inscripcion` */

DROP TABLE IF EXISTS `vista_inscripcion`;

/*!50001 DROP VIEW IF EXISTS `vista_inscripcion` */;
/*!50001 DROP TABLE IF EXISTS `vista_inscripcion` */;

/*!50001 CREATE TABLE  `vista_inscripcion`(
 `id_inscripcion` int(11) ,
 `codigo_periodo` varchar(15) ,
 `codigo_seccion` varchar(15) ,
 `codigo_alumno` varchar(15) ,
 `transporte` varchar(50) ,
 `telefono_transporte` varchar(40) ,
 `emergencia` varchar(100) ,
 `telefono_emergencia` varchar(40) ,
 `nombre` varchar(100) ,
 `login` varchar(20) ,
 `fecha` date ,
 `descripcion_seccion` varchar(100) ,
 `descripcion_periodo` varchar(100) ,
 `descripcion_turno` varchar(100) ,
 `nombre_representante` varchar(100) ,
 `direccion_representante` varchar(150) ,
 `correo_representante` varchar(40) ,
 `telefono_representante` varchar(40) ,
 `nombre_usuario` varchar(100) ,
 `edad` int(6) 
)*/;

/*View structure for view vista_inscripcion */

/*!50001 DROP TABLE IF EXISTS `vista_inscripcion` */;
/*!50001 DROP VIEW IF EXISTS `vista_inscripcion` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_inscripcion` AS select `a`.`id_inscripcion` AS `id_inscripcion`,`a`.`codigo_periodo` AS `codigo_periodo`,`a`.`codigo_seccion` AS `codigo_seccion`,`a`.`codigo_alumno` AS `codigo_alumno`,`a`.`transporte` AS `transporte`,`a`.`telefono_transporte` AS `telefono_transporte`,`a`.`emergencia` AS `emergencia`,`a`.`telefono_emergencia` AS `telefono_emergencia`,`d`.`nombre` AS `nombre`,`a`.`login` AS `login`,`a`.`fecha` AS `fecha`,`b`.`descripcion` AS `descripcion_seccion`,`c`.`descripcion` AS `descripcion_periodo`,`e`.`descripcion` AS `descripcion_turno`,`f`.`nombre` AS `nombre_representante`,`f`.`direccion` AS `direccion_representante`,`f`.`correo` AS `correo_representante`,`f`.`telefono` AS `telefono_representante`,`u`.`nombre` AS `nombre_usuario`,((year(`a`.`fecha`) - year(`d`.`fecha_nacimiento`)) - (right(`a`.`fecha`,5) < right(`d`.`fecha_nacimiento`,5))) AS `edad` from ((((((`tbl_inscripcion` `a` join `tbl_seccion` `b` on((`a`.`codigo_seccion` = `b`.`codigo_seccion`))) join `tbl_periodo` `c` on((`a`.`codigo_periodo` = `c`.`codigo_periodo`))) join `tbl_alumnos` `d` on((`a`.`codigo_alumno` = `d`.`codigo_alumno`))) join `tbl_turno` `e` on((`e`.`codigo_turno` = `b`.`codigo_turno`))) join `tbl_representante` `f` on((`f`.`codigo_representante` = `d`.`codigo_representante`))) left join `tbl_usuario` `u` on((`u`.`login` = `a`.`login`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
