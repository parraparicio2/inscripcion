

 DROP PROCEDURE IF EXISTS  `sp_alumnos`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_alumnos`(
  p_codigo_alumno VARCHAR(15),
  p_codigo_representante VARCHAR(15),
  p_nombre VARCHAR(60),
  p_fecha_nacimiento date,
  p_tipo_sangre VARCHAR(150)
)
BEGIN
       INSERT INTO tbl_alumnos
                   (
                   codigo_alumno, 
                   codigo_representante,
                   nombre,
                   fecha_nacimiento,
                   tipo_sangre
                   )
            VALUES (
                   p_codigo_alumno, 
                   p_codigo_representante,
                   p_nombre,
                   p_fecha_nacimiento,
                   p_tipo_sangre
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  codigo_alumno = p_codigo_alumno, 
                   codigo_representante = p_codigo_representante,
                   nombre = p_nombre,
                   fecha_nacimiento = p_fecha_nacimiento,
                   tipo_sangre = p_tipo_sangre;
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_inscripcion`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_inscripcion`(
   
   p_codigo_periodo varchar(15),
   p_codigo_seccion varchar(15),
   p_codigo_alumno varchar(15),
   p_login varchar(20),
   p_fecha date 
)
BEGIN
declare r_id_inscripcion bigint;
    
           INSERT INTO tbl_inscripcion
                   (
                   codigo_periodo, 
                   codigo_seccion, 
                   codigo_alumno, 
                   login,
                   fecha
                   )
            VALUES (
                   p_codigo_periodo,
                   p_codigo_seccion,  
                   p_codigo_alumno, 
                   p_login,
                   p_fecha
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  codigo_periodo = p_codigo_periodo,
                   codigo_seccion = p_codigo_seccion,  
                   codigo_alumno = p_codigo_alumno, 
                   login = p_login,
                   fecha = p_fecha;
                   
   
      set r_id_inscripcion = LAST_INSERT_ID();
      select r_id_inscripcion;
   
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_maestros`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_maestros`(
  p_codigo_maestro VARCHAR(15),
  p_nombre VARCHAR(60),
  p_telefono VARCHAR(40),
  p_direccion VARCHAR(150),
  p_correo VARCHAR(40)
)
BEGIN
       INSERT INTO tbl_maestros
                   (
                   codigo_maestro,
                   nombre,
                   telefono,
                   direccion,
                   correo)
            VALUES (
                   p_codigo_representante,
                   p_nombre,
                   p_telefono,
                   p_direccion,
                   p_correo
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  nombre = p_nombre,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   correo = p_correo;
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_periodos`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_periodos`(
   p_codigo_periodo varchar(15),
   p_descripcion varchar(160),
   p_periodo_actual bool
)
BEGIN
    
      INSERT INTO tbl_periodo
                   (
                   codigo_periodo,
                   descripcion,
                   periodo_actual
                   )
            VALUES (
                    p_codigo_periodo,
                    p_descripcion,
                    p_periodo_actual
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion,
                  periodo_actual = p_periodo_actual;         
                  
        if p_periodo_actual = 1 then
           update tbl_periodo 
              set periodo_actual = 0
            where codigo_periodo <> p_codigo_periodo;   
        end if;          
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_representante`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_representante`(
  p_codigo_representante varchar(15),
  p_nombre varchar(60),
  p_telefono varchar(40),
  p_direccion varchar(150),
  p_conyugue varchar(100),
  p_correo varchar(40)
)
BEGIN
       INSERT INTO tbl_representante
                   (
                   codigo_representante,
                   nombre,
                   telefono,
                   direccion,
                   conyugue,
                   correo)
            VALUES (
                   p_codigo_representante,
                   p_nombre,
                   p_telefono,
                   p_direccion,
                   p_conyugue,
                   p_correo
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  nombre = p_nombre,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   conyugue = p_conyugue,
                   correo = p_correo;
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_seccion`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_seccion`(
  p_codigo_seccion varchar(15),
  p_codigo_turno varchar(15),
  p_descripcion varchar(160),
  p_cupos int
  
)
BEGIN
       INSERT INTO tbl_seccion
                   (
                   codigo_seccion,
                   codigo_turno,
                   descripcion,
                   cupos
                   )
            VALUES (
                    p_codigo_seccion,
                    p_codigo_turno,
                    p_descripcion,
                    p_cupos
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion,
                  codigo_turno = p_codigo_turno,
                  cupos = p_cupos;      
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_turno`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_turno`(
   p_codigo_turno varchar(15),
   p_descripcion varchar(60)
)
BEGIN
       INSERT INTO tbl_turno
                   (
                   codigo_turno,
                   descripcion)
            VALUES (
                    p_codigo_turno,
                    p_descripcion
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion;          
    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_usuario`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_usuario`(
  p_login VARCHAR(15),
  p_nombre VARCHAR(60),
  p_correo DATE,
  p_telefono VARCHAR(40),
  p_direccion varchar(100),
  p_clave varchar(100),
  p_tipo varchar(10)
)
BEGIN
       INSERT INTO tbl_usuario
                   (
                   login, 
                   nombre,
                   correo,
                   telefono,
                   direccion,
                   clave,
                   tipo,
                   fecha
                   
                   )
            VALUES (
                   p_login, 
                   p_nombre,
                   p_correo,
                   p_telefono,
                   p_direccion,
                   md5(p_clave),
                   p_tipo,
                   current_date
                   )
                    
        ON DUPLICATE KEY 
           UPDATE  login = p_login, 
                   nombre = p_nombre,
                   correo = p_correo,
                   telefono = p_telefono,
                   direccion = p_direccion,
                   clave = md5(p_clave),
                   tipo = p_tipo;

    END  $$
DELIMITER ;



 DROP PROCEDURE IF EXISTS  `sp_verificar_inscripcion`  ;

DELIMITER $$

 CREATE  PROCEDURE `sp_verificar_inscripcion`(
   p_codigo_alumno varchar(15),
   p_codigo_seccion varchar(15),
   p_codigo_periodo varchar(15)
)
BEGIN
    declare v_contador integer;
    declare r_mensaje varchar(100); 
    declare r_valido bool;
    declare v_cupos integer;
    
	 SET r_mensaje = '';
	 SET r_valido = 1;
       SELECT COUNT(*) 
         into v_contador 
         FROM tbl_inscripcion 
        WHERE codigo_alumno = p_codigo_alumno 
          AND codigo_seccion = p_codigo_seccion
          and codigo_periodo = p_codigo_periodo;
         
       if (v_contador > 0) then
          set r_mensaje = 'El Alumno ya ha sido inscrito en este periodo escolar';
          set r_valido = 0;
       end if;
       
		  SELECT (SELECT COALESCE(cupos,0) FROM tbl_seccion WHERE codigo_seccion = p_codigo_seccion) - COALESCE(COUNT(*),0)   
			   into v_cupos 
				FROM tbl_inscripcion 
			  WHERE codigo_seccion = p_codigo_seccion 
				 AND codigo_periodo = p_codigo_periodo;
				 
				 if (v_cupos <= 0) then
					 SET r_mensaje = 'Ya no hay cupos en esta sección intente en otra';
					 SET r_valido = 0;
				 end if;  
				 
           
       SELECT r_mensaje, r_valido;
    END  $$
DELIMITER ;
