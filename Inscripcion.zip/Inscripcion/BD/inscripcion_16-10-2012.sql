/*
SQLyog Ultimate v9.02 
MySQL - 5.5.16-log : Database - bdinscripcion
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bdinscripcion` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bdinscripcion`;

/*Table structure for table `tbl_alumnos` */

DROP TABLE IF EXISTS `tbl_alumnos`;

CREATE TABLE `tbl_alumnos` (
  `codigo_alumno` varchar(15) NOT NULL,
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `tipo_sangre` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`codigo_alumno`),
  KEY `codigo_representante` (`codigo_representante`),
  CONSTRAINT `tbl_alumnos_ibfk_1` FOREIGN KEY (`codigo_representante`) REFERENCES `tbl_representante` (`codigo_representante`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_alumnos` */

LOCK TABLES `tbl_alumnos` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_inscripcion` */

DROP TABLE IF EXISTS `tbl_inscripcion`;

CREATE TABLE `tbl_inscripcion` (
  `id_inscripcion` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_periodo` varchar(15) NOT NULL,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_alumno` varchar(15) NOT NULL,
  `login` varchar(20) NOT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id_inscripcion`),
  KEY `codigo_periodo` (`codigo_periodo`),
  KEY `codigo_alumno` (`codigo_alumno`),
  KEY `codigo_seccion` (`codigo_seccion`),
  KEY `login` (`login`),
  CONSTRAINT `tbl_inscripcion_ibfk_1` FOREIGN KEY (`codigo_periodo`) REFERENCES `tbl_periodo` (`codigo_periodo`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_2` FOREIGN KEY (`codigo_alumno`) REFERENCES `tbl_alumnos` (`codigo_alumno`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_3` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `tbl_inscripcion_ibfk_4` FOREIGN KEY (`login`) REFERENCES `tbl_usuario` (`login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_inscripcion` */

LOCK TABLES `tbl_inscripcion` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_maestros` */

DROP TABLE IF EXISTS `tbl_maestros`;

CREATE TABLE `tbl_maestros` (
  `codigo_maestro` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_maestro`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_maestros` */

LOCK TABLES `tbl_maestros` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_periodo` */

DROP TABLE IF EXISTS `tbl_periodo`;

CREATE TABLE `tbl_periodo` (
  `codigo_periodo` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `tbl_periodo_actual` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`codigo_periodo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_periodo` */

LOCK TABLES `tbl_periodo` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_representante` */

DROP TABLE IF EXISTS `tbl_representante`;

CREATE TABLE `tbl_representante` (
  `codigo_representante` varchar(15) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `conyugue` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`codigo_representante`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_representante` */

LOCK TABLES `tbl_representante` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_seccion` */

DROP TABLE IF EXISTS `tbl_seccion`;

CREATE TABLE `tbl_seccion` (
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_seccion`),
  KEY `codigo_turno` (`codigo_turno`),
  CONSTRAINT `tbl_seccion_ibfk_1` FOREIGN KEY (`codigo_turno`) REFERENCES `tbl_turno` (`codigo_turno`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion` */

LOCK TABLES `tbl_seccion` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_seccion_maestros` */

DROP TABLE IF EXISTS `tbl_seccion_maestros`;

CREATE TABLE `tbl_seccion_maestros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_seccion` varchar(15) NOT NULL,
  `codigo_maestro` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codigo_maestro` (`codigo_maestro`),
  KEY `codigo_seccion` (`codigo_seccion`),
  CONSTRAINT `tbl_seccion_maestros_ibfk_1` FOREIGN KEY (`codigo_maestro`) REFERENCES `tbl_maestros` (`codigo_maestro`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_seccion_maestros_ibfk_2` FOREIGN KEY (`codigo_seccion`) REFERENCES `tbl_seccion` (`codigo_seccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_seccion_maestros` */

LOCK TABLES `tbl_seccion_maestros` WRITE;

UNLOCK TABLES;

/*Table structure for table `tbl_turno` */

DROP TABLE IF EXISTS `tbl_turno`;

CREATE TABLE `tbl_turno` (
  `codigo_turno` varchar(15) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`codigo_turno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_turno` */

LOCK TABLES `tbl_turno` WRITE;

insert  into `tbl_turno`(`codigo_turno`,`descripcion`) values ('01','Tarde');

UNLOCK TABLES;

/*Table structure for table `tbl_usuario` */

DROP TABLE IF EXISTS `tbl_usuario`;

CREATE TABLE `tbl_usuario` (
  `login` varchar(20) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(40) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `clave` varchar(100) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tbl_usuario` */

LOCK TABLES `tbl_usuario` WRITE;

UNLOCK TABLES;

/* Procedure structure for procedure `sp_turno` */

/*!50003 DROP PROCEDURE IF EXISTS  `sp_turno` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_turno`(
   p_codigo_turno varchar(15),
   p_descripcion varchar(60)
)
BEGIN
       INSERT INTO tbl_turno
                   (
                   codigo_turno,
                   descripcion)
            VALUES (
                    p_codigo_turno,
                    p_descripcion
                   )
                    
        ON DUPLICATE KEY 
           UPDATE descripcion = p_descripcion;          
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
