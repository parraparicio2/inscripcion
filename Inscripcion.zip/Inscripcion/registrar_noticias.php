<?php
include("includes/funciones.php");


$objconex = new mysqli(SERVIDOR,USUARIO,PASSWORD,NOMBREBD);


$sql = $objconex->stmt_init();


$sql->prepare("INSERT INTO tbl_contenido (titulo,descripcion,fecha_inicio,fecha_exp) VALUES (?,?,?,?)");


$sql->bind_param('ssss', $_POST['txtTitulo'],$_POST['txtDescripcion'],$_POST['txtFechai'],$_POST['txtFechaf']);


$sql->execute();


$sql->close();



header('location:noticias.php');

?>
<!--<script>
window.location = 'representante.php';
</script>-->