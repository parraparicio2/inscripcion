<?php 
include("includes/funciones.php");
include("inc/cabecera.php");
include("inc/pie.php");
?>

