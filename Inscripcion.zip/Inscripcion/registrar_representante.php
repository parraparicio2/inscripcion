<?php
include("includes/funciones.php");
abrirSesion();
//echo $_POST['txtmodo']; 
if ($_POST['txtModo']!="E")
{
	$sql="CALL sp_representante('".$_POST['txtCodigo']."','".$_POST['txtNombre']."','".$_POST['txtTelefono']."','".$_POST['txtDireccion']."','".$_POST['txtConyugue']."','".$_POST['txtCorreo']."')";
	
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Guardado')</script>";

}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_representante where codigo_representante = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	

?>
<script>
window.location = 'representante.php';
</script>