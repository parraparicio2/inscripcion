
  <!--<link rel="stylesheet" href="css/principal.css">-->

<?php 
include("includes/funciones.php");
include("inc/cabecera2.php");
?>
   <div id="agrupar">
   	
      <?php
	 $id_contenido=$_GET['id_contenido'];
	 $sql="select * from tbl_contenido where id_contenido = '$id_contenido'";
		//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $id_contenido=$campo['id_contenido'];
			  
	?>	
     <section id="">
         <article>
            <header>
            	<h2><?php echo $campo['titulo']; ?></h2>
            </header>
            <div id="imagen_contenido">
                <a href="contenido_ver.php?id_contenido=<?php echo $id_contenido?>">
                   <img id='foto' src="cargarImagen.php?id_foto=<?php echo $id_contenido ?>"/>
                </a>   
            </div>    
                <p><?php echo $campo['descripcion']; ?></p>
               <footer>
               	<a href="javascript:window.location='index.php'" style="color:#09F">Volver a la página principal </a>
               </footer>
         </article>
         
<?php 
		   }
	    }
?>         
     </section>
   </div>

<?php 
		   
	include("inc/pie.php");    
?>
