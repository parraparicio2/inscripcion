﻿

<?php
if (isset($_POST['txtCodigo']))
   $Codigo = $_POST['txtCodigo'];
   
if (isset($_GET['txtCodigo']))
   $Codigo = $_GET['txtCodigo'];


// SELECT * FROM tbl_contenido ORDER BY fecha_inicio DESC LIMIT 10 
include("includes/funciones.php");
include("inc/cabecera2.php");
//include("inc/cabecera2.php");
//abrirSesion();
 //SELECT * FROM `tbl_alumnos` WHERE `codigo_representante`
 
 
 $sql = "select * from tbl_alumnos where codigo_representante  = '".$Codigo. "'";

  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		
	   }

?>
   <div id="agrupar">
             <table id ="one-column-emphasis">
              <tr>
                 
                 <td class ="etiqueta_reporte" >Nombre del Alumnos</td>
                 <td class ="etiqueta_reporte" style="width:10%">Fecha nacimiento</td>
                 <td class ="etiqueta_reporte" style="width:15%">ver constantacia</td>
                 
                </tr>
				 <?php
           //   $i=1;
		   
		          
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				 $codigo_representante = $campo['codigo_representante'];
				 $codigo_alumno = $campo['codigo_alumno'];
                ?>
                  <tr>
                    
                     <td ><?php echo $campo['nombre']?></td>
                     <td ><?php echo transformarFecha($campo['fecha_nacimiento'])?></td>
                     <td align="center" ><a href="constancia_ver.php?codigo_alumno=<?php echo $codigo_alumno?>">Ver...</a></td>
                  </tr>
                <?php 
                 }
                ?>
        
         	</table>
       
		</div>
		
<?php
 

?>		
<?php
 
include("inc/pie.php");
?>
  
