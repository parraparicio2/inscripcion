<?php 
include("includes/funciones.php");
include("inc/cabecera2.php");


  echo' <div id="agrupar">
  
      <article>
            <header>
            	<h2>Preescolar Loma Linda</h2>
            </header>
             
                <p>
El preescolar Loma Linda esta ubicado en la avenida fuerzas armadas, en Conjunto Residencial  Loma Linda, detrás del salón de fiestas de dicha urbanización, fue fundado en el año 1989, en el mes de octubre, por la Magister –Licenciada  Fanny Chaparro,  quien con esmero, dedicación, y amor a la profesión docente, emprendió un arduo trabajo por todos los sectores adyacentes en busca de matricula escolar para hacer realidad un sueño,  aperturar el preescolar Loma Linda.   Acudió a  varias instituciones públicas y privadas : Obras Públicas del Estado, Ministerio del Poder Popular de Educación, Asociación de Vecinos del Conjunto Residencial, FEDE,  Gobernación del Zulia,  y demás personas vinculadas a la educación, para solicitar su ayuda y poner en funcionamiento su proyecto educativo.  Hoy, gracias a ellos se viò cristalizado el gran sueño de que los niños tengan un segundo hogar.
Se inicio con un solo turno, con una matricula de 46 niños,  en la mañana, y en el año 1991 se ponen en funcionamiento el turno de la tarde.  Hoy cuenta con una matricula de 240 niños y una comunidad de  206 padres y representantes Cuenta con un excelente personal profesional, calificado y capacitado, donde prevalece la calidad humana por encima de cualquier factor, seguido del amor a la profesión y la calidad educativa.
Hoy Loma Linda es y seguirá siendo  "Un Gran preescolar"  digno de emular, impartiendo la educación  gratuita de calidad a todos los que la reciben.
de seguir trabajando por enaltecer la educación pública y por ende la educación inicial que se desea para construir una sociedad digna y una patria linda y mas humana.
</p>
               <footer>
              
               </footer>
         </article>
         <article>
           
         </article></div>';
      
   

include("inc/pie.php");
?>
