<?php
include("includes/funciones.php");
abrirSesion();

$txtPeriodoActual = "1";	  

if (!isset($_POST['txtPeriodoActual']))
  {
  $txtPeriodoActual = "0";
  }
   
if ($_POST['txtModo']!="E")
{
	$sql="call sp_periodos('".$_POST['txtCodigo']."','".$_POST['txtDescripcion']."','".$txtPeriodoActual."')";
	
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Guardado')</script>";

}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_periodo where codigo_periodo = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	
?>
<script>
window.location = 'periodos.php';
</script>