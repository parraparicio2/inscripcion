<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<table width="797" height="1020" border="0">
  <tr>
    <td width="787"><img src="imagenes/membrete buena coonducta.JPG" width="787" height="357" /></td>
  </tr>
  <tr>
    <td height="154"><div>
      <div><p align="justify">Que    el  (la) niño (a): <strong><u></u></strong>Nacido (a)  en la ciudad de _________________ Estado ___________________el día   ____________/________/_______/, de   _________ Años    de edad,  cursó en esta Institución la sala de  ( ______ )  años de Educación Inicial, observando  una <strong>conducta  intachable y un   excelente rendimiento Escolar  _____________</strong>..con cedula escolar :  ______________________&#13;</p></div>
      <div>&#13;</div>
      <div>&#13;</div>
      <div>Constancia que se expide en la ciudad de Maracaibo a los  (______) día    del  mes de  _________________  del Año  &#13;</div>
      <div>&#13;</div>
    
      <div></div>
    </div></td>
  </tr>
  <tr>
    <td height="443"><img src="imagenes/pie de contancia.JPG" width="806" height="409" /></td>
  </tr>
</table>
</body>
</html>
