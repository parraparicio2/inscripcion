<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CONSTANCIA DE ESTUDIO</title>

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>


<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>


</head>

<body>

<?php
if (isset($_POST['codigo_alumno']))
   $Codigo = $_POST['codigo_alumno'];
   
if (isset($_GET['codigo_alumno']))
   $Codigo = $_GET['codigo_alumno'];




include("includes/funciones.php");

 
 $sql = "select * from vista_inscripcion where codigo_alumno  = '".$Codigo. "'";

  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		
	   }

?> 
<div id="div_principal">
           
           <table width="809" height="1020" border="0">
              <tr>
                <td width="803"><img src="imagenes/membrete buena coonducta.JPG" width="793" height="357" /></td>
              </tr>
				 <?php
           //   $i=1;
		   
		  
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				//$codigo_representante = $campo['codigo_representante'];
                ?>
                  
                  <tr>
    <td height="154" style="width:200px;">
      Que    el  (la) niño (a): <?php echo $campo['nombre']?>  Nacido (a)  en la ciudad de  <?php echo $campo['lugar_nacimiento']?>  Estado   <?php echo $campo['estado']?>  el  día  <?php echo transformarFecha($campo['fecha_nacimiento'])?> de <?php echo $campo['edad']?>  Años    de edad,  cursó en esta Institución la sala de  ( s )  años de Educación Inicial, observando  una  conducta  intachable  y un  excelente rendimiento Escolar  s  con cedula escolar :  s    .</br></br>
      
      
          Constancia que se expide en la ciudad de Maracaibo a la fecha:  s .
      
    </td>
  </tr>
  <tr>
                  
                  
                  
                  
                  
                
                <?php 
                 }
                ?>
     

<?php ?>
  




 

  <tr>
    <td height="443"><img src="imagenes/pie de contancia.JPG" width="806" height="409" /></td>
  </tr>
  <tr><td align="center">
     <div class="botones_reporte">
          <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
          <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='estudio.php'" class ="boton_comando"/>
    </div></td>
  </tr>
</table>
</div>
<script>

function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
}
</script>
</body>
</html>
