<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
#div_separador{
   float: left;
   width:95%; 
   margin:5px;
   padding:10px;
   border:#F00 solid 1px;
	
}

#tabla_inscripcion{
	width:100%;
}
</style>


<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="./js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="./js/jquery.js"></script>
<script>
$(document).ready(function(){
//verificamos los datos de inscripcion si ya existe
$('#cmdguardar').click( function(){
 
    if($('#cmdguardar').val()!= ""){
        $.ajax({
            type: "POST",
            url: "verificar_inscripcion.php",
            data:$("#frmDatos").serialize(),
            beforeSend: function(){
              //$('#msgUsuario').html('verificando');
            },
            success: function( respuesta ){
				 var resultado = jQuery.parseJSON(respuesta);
				if (resultado.valido== '1')
				  botonGuardar()
				else if (resultado.valido== '0')
				   {
					alert(resultado.mensaje);   
					return false;
				   }   
            }
            
        }); 
    }
});   


});
</script>



<title>Inscripción de Alumnos</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Incripciones De Nuevos alumnos </div>
<?php

include("includes/funciones.php");
abrirSesion();
//abrirSesionAdministrador();

$sql="SELECT COALESCE(MAX(id_inscripcion),0) + 1 AS id_inscripcion FROM tbl_inscripcion";
$consulta=ejecutarConsulta($sql);
$campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);

$txtCodigo = $campo['id_inscripcion'];

$txtCodigoAlumno= "";
$txtNombre = "";
$txtCodigoSeccion= "";
$txtCodigoPeriodo= "";
$txtFecha = date("d/m/Y"); 
$txtEdad = ""; 
$txtTransporte = "";
$txtEmergencia = "";
$txtTelefonoEmergencia = "";
$txtTelefonoTransporte = "";
$txtNombreSeguro = "";
$txtTelefonoSeguro = "";
//$txtSeguro = "0";
$txtClave = "";
$txtCedulaM = "";
$txtNombreM = "";
$txtTelefonoM = "";
$txtProfesionM = "";
$txtTrabajoM = "";
$txtCedulaP = "";
$txtNombreP = "";
$txtTelefonoP = "";
$txtProfesionP = "";
$txtTrabajoP = "";
$txtNacionalidadM = "";
$txtNacionalidadP = "";
$txtFechaM = "";
$txtFechaP = "";
$txtPreinscripcion = "0";

$txtModo="I";


if(isset($_POST['txtCodigoAlumno'])&& trim($_POST['txtCodigoAlumno']<>""))
  {
     $sql="select a.*, (YEAR(CURDATE())-YEAR(fecha_nacimiento)) - (RIGHT(CURDATE(),5)<RIGHT(fecha_nacimiento,5)) as edad from tbl_alumnos a where codigo_alumno ='".trim($_POST['txtCodigoAlumno'])."'";
	 $consulta=ejecutarConsulta($sql);
     if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigoAlumno=$campo['codigo_alumno'];
			  $txtNombre=$campo['nombre'];
			  $txtEdad=$campo['edad']." Años";
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Alumno no Registrado');</script>";
							 }
	}
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario" style="width:700px">
  <div id="header_formulario">Inscripción de Alumnos
  </div><!--cabecera-->

<div id="div_separador">
<table id="tabla_inscripcion">
<tr>
  <th height="50" colspan="2" scope="col">Datos del Alumno</th>
</tr>
<tr>
  <td height="45" class="etiqueta" width="300px">Código Alumno</td>
  <td>
  <input type="text" name="txtCodigoAlumno" id="txtCodigoAlumno" size="40" maxlength="60"value="<?php echo $txtCodigoAlumno ?>" lang="El Código del Alumno" class="txt_mediano"  onblur="buscar()" /> <input type ="button" onclick="abrirBusqueda('frmDatos', 'txtCodigoAlumno','busqueda.php',  sqlCodigo, sqlDescripcion, 1)"id="boton_browse" value ="..." />
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Nombre</td>
  <td>
   <span id="txtNombre" name = "txtNombre" class="etiqueta_informacion"><?php echo $txtNombre ?> </span>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Edad</td>
  <td>
   <span class ="etiqueta_informacion"><?php echo $txtEdad ?></span>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Sección</td>
  <td>
     <select class="combo_largo" name="txtCodigoSeccion" id="txtCodigoSeccion" >
       <?php 
	   $sql = "select * from tbl_seccion";
	   $consulta=ejecutarConsulta($sql);
       while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
         {
		 ?>
		 <option value='<?php echo $campo['codigo_seccion'];?>'><?php echo $campo['descripcion'];?></option>
         <?php    
         }   
         ?>
     </select>  
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Periodo Escolar</td>
  <td>
     <select class="combo_largo" name="txtCodigoPeriodo" id="txtCodigoPeriodo" >
       <?php 
	   $sql = "select * from tbl_periodo";
	   $consulta=ejecutarConsulta($sql);
       while ($campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
         {
		 ?>
		 <option value='<?php echo $campo['codigo_periodo'];?>'><?php echo $campo['descripcion'];?></option>
         <?php    
         }   
         ?>
     </select>  
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Tiene hermanos en el plantel</td>
  <td>
     <select class="combo_largo" name="cbHermano" id="cbHermano" onchange="tieneHermanos()">
		 <option value='0'>No</option>
       <option value='1'>Sí</option>
     </select>  
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">En que Sala</td>
  <td>
  <input type="text" name="txtCodigoSeccionHermano" id="txtCodigoSeccionHermano" value="" lang="en que Sala" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">En caso de emergencia llamar a</td>
  <td>
  <input type="text" name="txtEmergencia" id="txtEmergencia" value="<?php echo $txtEmergencia ?>" lang="Llamar en caso de emergencia" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Teléfono Emergencia</td>
  <td>
  <input type="text" name="txtTelefonoEmergencia" id="txtTelefonoEmergencia" value="<?php echo $txtTelefonoEmergencia ?>" lang="Telefono de emergencia" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Nombre del Transportista</td>
  <td>
  <input type="text" name="txtTransporte" id="txtTransporte" value="<?php echo $txtTransporte ?>" lang="El transporte" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Teléfono del Transportista</td>
  <td>
  <input type="text" name="txtTelefonoTransporte" id="txtTelefonoTransporte" value="<?php echo $txtTelefonoTransporte ?>" lang="Telefono del transporte" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Tiene Seguro</td>
  <td>
     <select class="combo_corto" name="cbSeguro" id="cbSeguro" onchange="tieneSeguro()">
		 <option value='0'>No</option>
       <option value='1'>Sí</option>
     </select>  
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Nombre del Seguro</td>
  <td>
  <input type="text" name="txtNombreSeguro" id="txtNombreSeguro" value="<?php echo $txtNombreSeguro ?>" lang="El nombre del Seguro" class="txt_largo"/>
  </td>
</tr>

<tr>
  <td height="45" class="etiqueta">Clave del Seguro</td>
  <td>
  <input type="text" name="txtClave" id="txtClave" value="<?php echo $txtClave ?>" lang="El clave del Seguro" class="txt_mediano"/>
  </td>
</tr>


<tr>
  <td height="45" class="etiqueta">Teléfono del Seguro</td>
  <td>
  <input type="text" name="txtTelefonoSeguro" id="txtTelefonoSeguro" value="<?php echo $txtTelefonoSeguro ?>" lang="El telefono del Seguro" class="txt_largo"/>
  </td>
</tr>



  <td height="45" class="etiqueta">Fecha de Inscripción</td>
  <td>
  <input type="text" name="txtFecha" id="txtFecha" value="<?php echo $txtFecha ?>" lang="La Fecha" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
  </td>
</tr>
  </table>
  
  </div><!--div id="div_separador"-->
<!--------------------------------------------------------------------------------------------------->
<div id="div_separador">
<table id="tabla_inscripcion">
<tr>
  <th height="50" colspan="2" scope="col">Datos de la Mamá</th>
</tr>

    <tr>
      <td height="45" width="300px" class="etiqueta">Cédula</td>
      <td>
      <input type="text" name="txtCedulaM" id="txtCedulaM" value="<?php echo $txtCedulaM ?>" lang="La cédula de la mamá" class="txt_mediano" onblur="buscarMama()"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Nombre</td>
      <td>
      <input type="text" name="txtNombreM" id="txtNombreM" value="<?php echo $txtNombreM?>" lang="El Nombre de la mamá" class="txt_largo"/>
      </td>
    </tr>
    
    <tr>
      <td height="45" class="etiqueta">Nacionalidad</td>
      <td>
     <select class="combo_largo" name="txtNacionalidadM" id="txtNacionalidadM" >
		 <option value='V'>Venezolano</option>
       <option value='E'>Extranjero</option>
     </select>  
      </td>
    </tr>
    <tr>
      <td height="45" class="etiqueta">Fecha de Nacimiento</td>
      <td>
      <input type="text" name="txtFechaM" id="txtFechaM" value="<?php echo $txtFechaM ?>" lang="La Fecha de nacimiento de la mamá" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendarioM"/> DD/MM/AAAA
      </td>
    </tr>
    
    <tr>
      <td height="45" class="etiqueta">Profesión</td>
      <td>
      <input type="text" name="txtProfesionM" id="txtProfesionM" value="<?php echo $txtCedulaM ?>" lang="La profesión de la mamá" class="txt_largo"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Donde Trabaja</td>
      <td>
      <input type="text" name="txtTrabajoM" id="txtTrabajoM" value="<?php echo $txtTrabajoM ?>" lang="donde trabaja" class="txt_largo"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Teléfono</td>
      <td>
      <input type="text" name="txtTelefonoM" id="txtTelefonoM" value="<?php echo $txtTelefonoM ?>" lang="El Telefono de la mamá" class="txt_largo"/>
      </td>
    </tr>
</table>    
  </div><!--div id="div_separador"-->
<!-------------------------------------------------------------------------------------------------------------------->    
  <div id="div_separador">
<table id="tabla_inscripcion">
<tr>
  <th height="50" colspan="2" scope="col">Datos del Papá</th>
</tr>

    <tr>
      <td height="45" width="300px" class="etiqueta">Cédula</td>
      <td>
      <input type="text" name="txtCedulaP" id="txtCedulaP" value="<?php echo $txtCedulaP ?>" lang="La cédula del papá" class="txt_mediano" onblur="buscarPapa()"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Nombre</td>
      <td>
      <input type="text" name="txtNombreP" id="txtNombreP" value="<?php echo $txtNombreP?>" lang="El Nombre del papá" class="txt_largo"/>
      </td>
    </tr>
    
    <tr>
      <td height="45" class="etiqueta">Nacionalidad</td>
      <td>
     <select class="combo_largo" name="txtNacionalidadP" id="txtNacionalidadP" >
		 <option value='V'>Venezolano</option>
       <option value='E'>Extranjero</option>
     </select>  
      </td>
    </tr>
    <tr>
      <td height="45" class="etiqueta">Fecha de Nacimiento</td>
      <td>
      <input type="text" name="txtFechaP" id="txtFechaP" value="<?php echo $txtFechaP ?>" lang="La Fecha de nacimiento del papá" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendarioP"/> DD/MM/AAAA
      </td>
    </tr>
    
    <tr>
      <td height="45" class="etiqueta">Profesión</td>
      <td>
      <input type="text" name="txtProfesionP" id="txtProfesionP" value="<?php echo $txtCedulaM ?>" lang="La profesión del papá" class="txt_largo"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Donde Trabaja</td>
      <td>
      <input type="text" name="txtTrabajoP" id="txtTrabajoP" value="<?php echo $txtTrabajoP ?>" lang="donde trabaja" class="txt_largo"/>
      </td>
    </tr>

    <tr>
      <td height="45" class="etiqueta">Teléfono</td>
      <td>
      <input type="text" name="txtTelefonoP" id="txtTelefonoP" value="<?php echo $txtTelefonoP ?>" lang="El Telefono del papá" class="txt_largo"/>
      </td>
    </tr>
    
</table>
</div><!--div id="div_separador"-->

<table id="tabla_inscripcion">
    
  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
    
</table>

  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
  <input id="txtCodigo" name="txtCodigo" type="hidden"value="<?php echo $txtCodigo ?>" />
  <input id="txtPreinscripcion" name="txtPreinscripcion" type="hidden"value="<?php echo $txtPreinscripcion ?>" />
  <input id="tabla" name="tabla" type="hidden"value="alumnos" />
</form>
<script>
tieneSeguro();
tieneHermanos();

 seleccionarCombo('txtCodigoPeriodo','<?php echo periodoActual()?>')
 
 var sqlCodigo = 'select codigo_alumno, nombre from tbl_alumnos where codigo_alumno like \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select codigo_alumno, nombre from tbl_alumnos where nombre like \'%@parametro_descripcion%\'';
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'txtTransporte,txtTelefonoTransporte') )
        return false;
	  
	 if (validarFecha('txtFecha') == false)
	    return false;	 

	 if (validarFecha('txtFechaM') == false)
	    return false;	 
	  
	 if (validarFecha('txtFechaP') == false)
	    return false;	 

	 document.forms[0].txtCodigoSeccionHermano.disabled = false;
	 document.forms[0].txtNombreSeguro.disabled = false;
	 document.forms[0].txtClave.disabled = false;
	 document.forms[0].txtTelefonoSeguro.disabled = false;

      document.frmDatos.action='registrar_inscripcion.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='inscripcion.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_inscripcion.php';  
	  document.frmDatos.submit();	  
   }
   
  Calendar.setup
  (
    {
      inputField     :    "txtFecha",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );

  Calendar.setup
  (
    {
      inputField     :    "txtFechaM",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendarioM",
      singleClick    :    true,
      step           :    2  
	                
	}
  );


  Calendar.setup
  (
    {
      inputField     :    "txtFechaP",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendarioP",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
   
function tieneSeguro()
{
	if (document.forms[0].cbSeguro.value==0)
	   {
		   document.forms[0].txtNombreSeguro.disabled = true;
		   document.forms[0].txtClave.disabled = true;
		   document.forms[0].txtTelefonoSeguro.disabled = true;

		   document.forms[0].txtNombreSeguro.value = '';
		   document.forms[0].txtClave.value = '';
		   document.forms[0].txtTelefonoSeguro.value = '';
		   
	   } 
	else
	   {
		   document.forms[0].txtNombreSeguro.disabled = false;
		   document.forms[0].txtClave.disabled = false;
		   document.forms[0].txtTelefonoSeguro.disabled = false;
		}   
	
}

function tieneHermanos()
{
	if (document.forms[0].cbHermano.value==0)
	   {
		   document.forms[0].txtCodigoSeccionHermano.disabled = true;

		   document.forms[0].txtCodigoSeccionHermano.value = '';
	   } 
	else
	   {
		   document.forms[0].txtCodigoSeccionHermano.disabled = false;
		}   
	
}  

//buscamos los datos de los padres
function buscarMama(){
    if($('#txtCedulaM').val()!= ""){
        
        $.ajax({
            type: "POST",
            url: "buscar_mama.php",
            data: "txtCedulaM="+$('#txtCedulaM').val(),
            beforeSend: function(){
            },
            success: function( respuesta ){
				
			var resultado = jQuery.parseJSON(respuesta);
              if(resultado.cedula_m != '')
              {
			    document.getElementById('txtNombreM').value = resultado.nombre_m;
				document.getElementById('txtTelefonoM').value = resultado.telefono_m;
				document.getElementById('txtProfesionM').value = resultado.profesion_m;
				document.getElementById('txtTrabajoM').value = resultado.trabajo_m;
				document.getElementById('txtFechaM').value = resultado.fecha_nac_m;
				if (resultado.nacionalidad_p == 'V')
				   document.forms[0].txtNacionalidadM.selectedIndex = 1;
				else
				   document.forms[0].txtNacionalidadM.selectedIndex = 1;
			  } 
            }
        });
	}
}	

function buscarPapa(){
    if($('#txtCedulaM').val()!= ""){
        
        $.ajax({
            type: "POST",
            url: "buscar_papa.php",
            data: "txtCedulaP="+$('#txtCedulaP').val(),
            beforeSend: function(){
            },
            success: function( respuesta ){
				
			var resultado = jQuery.parseJSON(respuesta);
              if(resultado.cedula_m != '')
              {
			    document.getElementById('txtNombreP').value = resultado.nombre_p;
				document.getElementById('txtTelefonoP').value = resultado.telefono_p;
				document.getElementById('txtProfesionP').value = resultado.profesion_p;
				document.getElementById('txtTrabajoP').value = resultado.trabajo_p;
				document.getElementById('txtFechaP').value = resultado.fecha_nac_p;
				if (resultado.nacionalidad_m == 'V')
				   document.forms[0].txtNacionalidadP.selectedIndex = 1;
				else
				   document.forms[0].txtNacionalidadP.selectedIndex = 1;
			  } 
            }
        });
	}
}	

  
 </script>
 </div>
 </div>
</body>
</html>