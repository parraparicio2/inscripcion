<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="js/funciones.js"></script>
<title>Consulta de Inscripción</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
    <div><img src="imagenes/logo gobierno.JPG" width="787" height="102" /></div>
   <div class="logo_reporte">   
   <img src="imagenes/logo_reportes.jpeg" style="height:100px">
</div>

<div class="titulo_reporte" style="margin-left:10%;">Consultas de contenido </div>


<?php

include("includes/funciones.php");
abrirSesion();
//abrirSesionAdministrador();
$txtFechaInicio= date("d/m/Y");


?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario pantalla_consulta" style="width:450px !important">
  <div id="header_formulario">Consulta de Contenidos
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Fecha Inicio</td>
  <td width="348">
  <input type="text" name="txtFechaInicio" id="txtFechaInicio" value="<?php echo $txtFechaInicio ?>" lang="La Fecha de Inicio" onblur="" class="txt_mediano"  style="width:60%" />
  <img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA 
</tr>
<tr>
  <td width="100" height="45" class="etiqueta">Fecha Final</td>
  <td width="348">
  <input type="text" name="txtFechaFin" id="txtFechaFin" value="<?php echo $txtFechaInicio ?>" lang="La Fecha Fin" onblur="" class="txt_mediano"  style="width:60%" /> 
  <img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario2"/> DD/MM/AAAA
</tr>

  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cmdguardar" id="cmdguardar" value="Aceptar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
</form>
<script>
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;
	  
	 if (validarFecha('txtFechaInicio') == false)
	    return false;	 
	  
     if (validarFecha('txtFechaFin') == false)
	    return false;	 
	  
	  document.frmDatos.action='reporte_contenidos.php';  
	  document.frmDatos.submit();
	  
   }
   
    Calendar.setup
  (
    {
      inputField     :    "txtFechaInicio",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );

  Calendar.setup
  (
    {
      inputField     :    "txtFechaFin",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario2",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
 </script>
 </div>
 </div>
</body>
</html>