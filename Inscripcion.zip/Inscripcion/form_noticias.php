<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js"></script>
<title>Registro de Noticias</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
<?php

include("includes/funciones.php");

$txtTitulo= "";
$txtDdescripcion= "";

$txtFechai = date("d/m/Y"); 
$txtFechaf = date("d/m/Y");

$txtModo="I";
 
?>
<form id="frmDatos" name="frmDatos" method="post" action="registrar_noticias.php" class="formulario">
  <div id="header_formulario">Registro de Noticias
  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>

<tr>
  <td height="45" class="etiqueta">Titulo</td>
  <td>
  <input type="text" name="txtTitulo" id="txtTitulo" size="40" maxlength="60"value="" lang="El Nombre" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Descripcion</td>
  <td>

<textarea name="txtDescripcion" id="txtDescripcion" cols="35" rows="3" lang="LA preparacion" required></textarea>  
 
  </td>
</tr>


<tr>
  <td height="45" class="etiqueta">Fecha inicio</td>
  <td>
  
   <input type="text" name="txtFechai" id="txtFechai" size="40" maxlength="60"value="<?php echo $txtFechai ?>" lang="La Fecha" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
  
 
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Fecha final</td>
  <td>
  
  <input type="text" name="txtFechaf" id="txtFechaf" size="40" maxlength="60"value="" lang="La Fecha" class="txt_mediano"/><img src="images/calendar2.gif" alt="" width="16" height="16"  id = "img_calendario2"/> DD/MM/AAAA
  
  
  </td>
</tr>

  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cdmeliminar" id="cdmeliminar" value="Eliminar" onclick="botonEliminar()" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
<script>
 
  function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') )
      return false;
	  
     //if (!validarCorreo(document.frmDatos.txtCorreo.value))
	   //return false;
	  

      document.frmDatos.action='registrar_noticias.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='representante.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_representante.php';  
	  document.frmDatos.submit();	  
   }
   
   Calendar.setup
  (
    {
      inputField     :    "txtFechai",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
  Calendar.setup
  (
    {
      inputField     :    "txtFechaf",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario2",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
 </script>
 </div>
 </div>
</body>
</html>