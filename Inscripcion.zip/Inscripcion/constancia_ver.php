<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CONSTANCIA DE ESTUDIO</title>

<LINK rel="stylesheet" href="css/estilos.css" type="text/css"/>
<LINK rel="stylesheet" href="css/tablas.css" type="text/css"/>

<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js">
</script><script type="text/javascript" src="js/funciones.js"></script>


</head>

<body>

<?php
if (isset($_POST['codigo_alumno']))
   $Codigo = $_POST['codigo_alumno'];
   
if (isset($_GET['codigo_alumno']))
   $Codigo = $_GET['codigo_alumno'];




include("includes/funciones.php");

 
 $sql = "select * from tbl_alumnos where codigo_alumno  = '".$Codigo. "'";

  $consulta = ejecutarConsulta($sql);

   if (mysqli_num_rows($consulta) > 0 )
	   { 
	      $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC);
		  $consulta = ejecutarConsulta($sql);
		
	   }

?>
           <table width="797" height="1020" border="0">
              <tr>
                <td width="787"><img src="imagenes/constancia de estudio.JPG" width="795" height="371" /></td>
              </tr>
				 <?php
           //   $i=1;
		   
		  
                 while( $campo = mysqli_fetch_array($consulta, MYSQLI_ASSOC))
                 { 
				//$codigo_representante = $campo['codigo_representante'];
                ?>
                  
                  <tr>
    <td height="154"><div>
      <div>
        <div>
          <div>Que    el  (la) niño (a<u>):</u><strong><u>  </u></strong><strong><u>  </u></strong><strong><u>____________<?php echo $campo['nombre']?>_____________________________</u></strong><strong><u>.</u></strong><strong><u>&#13;</u></strong></div>
          <div>Nacido (a)  en la ciudad de  _______SSSS________ Estado _______________   el    ______<?php echo $campo['nombre']?>/______/_______/de    ____DD_____ años  de edad,  con cedula escolar Nº __________DDDDDD_______________, cursó   la sala de ____D___años de educación inicial en esta  Institución hasta el mes _____D___del año______D_____,  siendo retirado por su representante en el mes de  ______D________del _____D________&#13;</div>
          <div>&#13;</div>
          <div>Constancia que se expide en la ciudad de Maracaibo a los   ___D___   días    del  mes de   ______D_______ del Año  ___D_____&#13;</div>
          <div></div>
        </div>
____________</div>
    </div></td>
  </tr>
  <tr>
                  
                  
                  
                  
                  
                
                <?php 
                 }
                ?>
     

<?php ?>
  




 

  <tr>
    <td height="443"><img src="imagenes/pie de contancia.JPG" width="806" height="409" /></td>
  </tr>
  <tr><td align="center">
     <div class="botones_reporte">
          <input type="button" value="Imprimir" onclick="imprimir()" id="cmdImprimir" class ="boton_comando"/>
          <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='estudio.php'" class ="boton_comando"/>
    </div></td>
  </tr>
</table>
<script>
function imprimir()
{
	mostrarBoton('cmdsalir', false);
	mostrarBoton('cmdImprimir', false);
	window.print();
	mostrarBoton('cmdsalir', true);
	mostrarBoton('cmdImprimir', true);
}
</script>
</body>
</html>
