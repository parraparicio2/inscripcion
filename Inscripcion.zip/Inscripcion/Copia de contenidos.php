<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/validar.js"></script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-en.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js"></script>

<script type="text/javascript">


$(document).ready(function(){
 $('#imagen1 > img').fadeOut(function(){

	var objImagePreloader = new Image();

	objImagePreloader.onload = function() {

                $('#imagen1 > img')

                    .removeAttr('src')

                    .attr('src','imagenes/no_disponible.jpeg')

                    .fadeIn();

	}

	objImagePreloader.src = 'imagenes/bigLoader.gif';

});


});//document ready

	function setpreview()
	{
	  document.frmDatos.target='null';
	  document.frmDatos.action='subirImagen.php';
	  document.frmDatos.submit();
	}
</script>
<title>Registro de Contenidos</title>
</head>
<body>

<div id="contenedor" >
   <div id="main" >
<?php

include("includes/funciones.php");
abrirSesion();
abrirSesionAdministrador();
$txtCodigo= "";
$txtTitulo= "";
$txtDescripcion= "";
$txtFechaInicio= date("d/m/Y");
$txtFechaFin= date("d/m/Y");
$txtResumen= "";
$txtModo= "I";
 if (isset($_GET['id_contenido']))
   $txtCodigo = $_GET['id_contenido'];
    
if(trim($txtCodigo) <> "")
  {
     $sql="select * from tbl_contenido where id_contenido ='".trim($txtCodigo)."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['id_contenido'];
			  $txtTitulo=$campo['titulo'];
			  $txtDescripcion=$campo['descripcion'];
			  $txtResumen=$campo['resumen'];
			  $txtFechaInicio=transformarFecha($campo['fecha_inicio']);
			  $txtFechaFin =transformarFecha($campo['fecha_exp']);
			  $txtModo= "A";
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}
 
?>
<form enctype="multipart/form-data" id="frmDatos" name="frmDatos" method="post" action="registrar_contenidos.php" class="formulario">
  <div id="header_formulario">Registro de Contenidos  </div><!--cabecera-->
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>

<tr>
  <td height="45" class="etiqueta">Título</td>
  <td>
  <input type="text" name="txtTitulo" id="txtTitulo" size="40" maxlength="60"value="<?php echo $txtTitulo ?>" lang="El Título" class="txt_largo"/>
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Resumen</td>
  <td><textarea name="txtResumen" id="txtResumen" class ="txt_largo" lang="El Resumen" ><?php echo $txtTitulo ?></textarea></td>
</tr>
<tr>
  <td height="45" class="etiqueta">Descripción</td>
  <td><textarea name="txtDescripcion" id="txtDescripcion" class ="txt_largo" lang="La Descripcion"><?php echo $txtDescripcion ?></textarea></td>
</tr>


<tr>
  <td height="45" class="etiqueta">Fecha Inicio</td>
  <td>
  <input type="text" name="txtFechaInicio" id="txtFechaInicio" size="40" maxlength="60"value="<?php echo $txtFechaInicio ?>" lang="La Fecha de Inicio" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario"/> DD/MM/AAAA
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Fecha Fin</td>
  <td>
  <input type="text" name="txtFechaFin" id="txtFechaFin" size="40" maxlength="60"value="<?php echo $txtFechaFin ?>" lang="La Fecha Fin" class="txt_mediano"/><img src="imagenes/calendar.gif" alt="" width="16" height="16"  id = "img_calendario2"/> DD/MM/AAAA
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Foto</td>
  <td>
  <div id="foto_contenido"><img id = "imagen1"  name="imagen1" src="imagenes/no_disponible.jpeg"></div>
  
  </td>
</tr>
<tr>
  <td height="45" class="etiqueta">Archivo</td>
  <td>
  <input class = "subir_archivos" id = "archivo1" name = "archivo1" type="file" value="Elegir" onChange="setpreview()" lang="la Imagen"/>
  </td>
</tr>
  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='menu.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
  <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
  <input id="txtCodigo" name="txtCodigo" type="hidden"value="<?php echo $txtCodigo?>" />
</form>

<script>

   function botonGuardar()
   {
	  
    if (validarDatos(document.frmDatos,'') )
        return false;
	  
	 if (validarFecha('txtFechaInicio') == false)
	    return false;	 
	  
     if (validarFecha('txtFechaFin') == false)
	    return false;	 
	  
	  document.frmDatos.target = '_self';
      document.frmDatos.action='registrar_contenidos.php';  
	  document.frmDatos.submit();
	  
   }
   function buscar()
   {
	  document.frmDatos.action='contenidos.php'; 
	  document.frmDatos.submit();
   }
   
  function botonEliminar()
   {
	  document.frmDatos.txtModo.value='E';
      document.frmDatos.action='registrar_contenidos.php';  
	  document.frmDatos.submit();	  
   }
   
  Calendar.setup
  (
    {
      inputField     :    "txtFechaInicio",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario",
      singleClick    :    true,
      step           :    2  
	                
	}
  );

  Calendar.setup
  (
    {
      inputField     :    "txtFechaFin",   
      ifFormat       :    "%d/%m/%Y",   
      showsTime      :    false,          
      button         :    "img_calendario2",
      singleClick    :    true,
      step           :    2  
	                
	}
  );
  
  function cargarImagen(objetoImagen, objetoFile)
{ var imagen = document.getElementById(objetoImagen);
  var archivo = document.getElementById(objetoFile);
   alert(imagen.src);
  imagen.src = 'file:///'+archivo.value;
     alert(imagen.src);
}
/**********cargar imagenes******************
	function setpreview()
	{
	  document.frmDatos.target='null';
	  document.frmDatos.action='subirImagen.php';
	  document.frmDatos.submit();
	}
/**********cargar imagenes*******************/

   
 </script>
 </div>
 </div>
 <iframe src="about:blank" name="null" style="display:none"><!--SIN ESTO NO FNCIONA LO DE LA IMAGEN-->
</body>
</html>