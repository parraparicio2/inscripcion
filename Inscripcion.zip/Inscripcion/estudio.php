<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<link rel="STYLESHEET" type="text/css" href="css/form.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<title>Registro de Representantes</title>
</head>
<body>

<div id="contenedor" >-->
  
<?php

include("includes/funciones.php");
include("inc/cabecera2.php");

 echo'<div id="agrupar">';

echo '<div id="main">';


$txtCodigo= "";



if(isset($_POST['txtCodigo'])&& trim($_POST['txtCodigo']<>""))
  {
   
   
     $sql="select * from tbl_alumnos where codigo_representante ='".trim($_POST['txtCodigo'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $txtCodigo=$campo['codigo_representante'];
			 
			
			
		  
		   }
	    }
	    else
			 {
			 	echo "<script> alert('registro no encontrado');</script>";
				$txtCodigo=$_POST['txtCodigo'];
			 }
	}




?>
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Introduzca su Cedula de Identidad
  </div><!--cabecera-->
  <div id="header_formulario2">cada constancia debe estar firmada y sellada por la institucion
  </div>
<table height="100%" border="0" width="100%">
<tr>
  <th height="50" colspan="2" scope="col"></th>
</tr>
<tr>
  <td width="100" height="45" class="etiqueta2">Cedula :</td>
  <td width="348" >
  <input type="text" name="txtCodigo" id="txtCodigo" value="<?php echo $txtCodigo;?>" lang="El Código" onblur="buscar()" class="txt_mediano"/> 
  </td>
</tr>


  <tr>
    <td height="100" colspan="2"><div align="center">
      <input type="reset" name="cdmeliminar" id="cdmeliminar" value="Reset" onclick="" class="boton_comando" />
      <input type="button" name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando"/>
      <input type="button" name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location='index.php'" class="boton_comando"/>
      </span></div></td>
  </tr>
  </table>
   
</form>
<script>


  
   function botonGuardar()
   {
     if (validarDatos(document.frmDatos,'') ){
      return false;
	  }
	    
    // if (!validarCorreo(document.frmDatos.txtCorreo.value))
	 //   return false;
     else	  
          {
      document.frmDatos.action='constancia_estudio.php';  
	  document.frmDatos.submit();
	  }
   }

   function buscar()
   {
	  document.frmDatos.action='estudio.php'; 
	  document.frmDatos.submit();
   }
   
 
 </script>
<?php echo '</div>';
      echo '</div>';
?>
 
<?php
include("inc/pie.php");
?>