<!DOCTYPE HTML>
<html>
    <head>
        <title>
            ..:: trabajo ::..
        </title>
        <link rel='stylesheet' type='text/css'  href='estilos/estilos.css'/>
        
    </head>    
<body>
<?php 
   include("inc/cabecera.php");
?>
<div id="contenedor">

   <div id="main">
    <div id= "cabecera">  
       <img src="./imagenes/encabezado.jpg" width="990" height="101">  
    </div>
        <div id="div_lateral">
          <?php
		      escribirMenu(); 
		   ?>
        </div><!--div_lateral-->
        <div id="contenido">
			<?php
            
            echo "<h1>Videos Recetas</h1><hr><br>";
            
            echo "<div id='div_video'></div>";
            
            echo "<div id='div_video'></div>";
            
            echo "<div id='div_video'></div>";
            
            echo "<div id='div_video'></div>";
            
            echo "<div id='div_video'></div>";
            
            echo "<div id='div_video'></div>";
            ?>        
         </div><!--contenido-->
    <div id='div_footer'>
        <footer>
        </footer>    
    </div>
         
   </div><!--main-->
</div><!--contenedor-->   

</body>
</html>


