<?php
//include_once("includes/funciones.php");
//include_once("includes/clase_publicacion.php");
require_once("configuracion/configurar.php");
//require_once("includes/clase_publicacion.php");
  if (empty($_GET['id_foto'])) 
    {
	
      exit();
    }
  else 
    {
		$id_foto = $_GET['id_foto'];
		if (!settype($id_foto, 'integer')) {
			$id_foto = -1;
		   echo "paso por aqui";
	 }
	 
  if ($id_foto == -1)
  {
			Header("Content-Type: image/jpeg"); // se envia la cabecera...
           $imagen = file_get_contents('images/no_disponible.jpeg');
		   echo $imagen;
  }   
  else if (($id_foto != -1) && ($id_foto > 0)) 
    {
		$link = mysqli_connect(SERVIDOR, USUARIO, PASSWORD, NOMBREBD);
		$sql = "CALL sp_buscar_foto_id(".$_GET['id_foto'].")";
		$result = mysqli_query($link, $sql);
		$datos = mysqli_fetch_array($result, MYSQL_ASSOC);
		$imagen = $datos['foto'];
		$mime = $datos['tipo'];
		header("Content-Type: $mime");
		echo $imagen;
	 }
  }
?>
