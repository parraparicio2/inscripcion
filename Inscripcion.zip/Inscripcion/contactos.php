<?php
include('inc/cabecera.php');


echo('contactos');

include('inc/pie.php');
?>