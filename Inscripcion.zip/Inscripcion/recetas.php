<?php
include('inc/cabecera.php');



$objconex=new mysqli('localhost','user','1234','recetas');

$resultado=$objconex->query("Select * from recetario");

echo "<h1>Recetas de nuestros usuarios </h1><hr><br>";
echo '<table border="1" align="center">';
echo '<tr><th>Autor</th><th>Titulo</th><th>Detalles</th></tr>';
while($registro=$resultado->fetch_object()){
    echo '<tr>';    
    echo '<td>'.$registro->Autor. '</td>';    
    echo '<td>'.$registro->Titulo. '</td>';
 
    echo '<td>'.'<a href="frmingresar.php">Detalles</a>'. '</td>';
    echo '</tr>';
}
echo '</table>';

echo "<br><a href='frmingresar.php'>Comparte tus Recetas</a>";


include('inc/pie.php');
?>