<?php
	// *** Include the class*/
	include("includes/SimpleImage.php");
    
	$carpeta="tmp/";

    //print_r($_FILES);
	 if (!empty($_FILES['archivo1']['name']))
	 {
		
	   echo "<script>parent.document.getElementById('imagen1').src='./images/bigLoader.gif'</script>"; 
      $image = new SimpleImage();
      $image->load($_FILES['archivo1']['tmp_name']);
      $image->resizeToWidth(400);
	   $image->save($_FILES['archivo1']['tmp_name']);

      $name=$carpeta.basename($_FILES['archivo1']['name']);
	   move_uploaded_file($_FILES['archivo1']['tmp_name'],$name);
	    print_r($_FILES);
		echo $name;
		echo "<script>parent.document.getElementById('imagen1').src='". $name. "'</script>"; 
     
}	 


?>
