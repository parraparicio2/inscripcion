<?php 
include("includes/funciones.php");
include("inc/cabecera2.php");


  echo' 
  
    <table align="center" style="width: 95%;" border="0">
<tbody>
<tr>
<td style="text-align: justify;" valign="middle"><span style="-webkit-border-horizontal-spacing: 0px; -webkit-border-vertical-spacing: 0px;"><span style="font-size: 12pt;"><img style="float: left; border-width: 0px; border-color: #000000; margin: 12px;" src="./imagenes/foto1.JPG" class="image" height="183" width="285"><span style="font-size: 10pt;"><span style="font-family: "comic sans ms", sans-serif;">Las instalaciones del preescolar fueron diseñadas para llenar las expectativas y necesidades de los niños, docentes, padres y comunidad.&nbsp;Su diseño permite una <strong>integración hacia el ambiente exterior a través de sus grandes ventanales</strong> y tomando en cuenta la luz natural como elemento principal.</span></span></span></span></td>
</tr>

<tr>
<td valign="middle">
<p style="text-align: justify;"><span style="-webkit-border-horizontal-spacing: 0px; -webkit-border-vertical-spacing: 0px;"><span style="font-size: 12pt;"><span style="font-size: 10pt;"><span style="font-family: "comic sans ms", sans-serif;"><img style="float: right; border-width: 0px; border-color: #000000; margin: 12px;" src="./imagenes/foto8.JPG"  class="image" height="183" width="285">Esta dotado &nbsp;de un <strong>parque infantil exterior</strong> &nbsp;para los más pequeñitos con mobiliario y &nbsp;juegos acordes a su edad. El jardín principal, consta de un parque de madera diseñado acorde a los parámetros propios de la edad preescolar, con juegos de arena y una casita de animales donde los niños podrán tenerlos a la vista y tener contacto con ellos.</span></span></span></span></p>
</td>
</tr>


<tr>
<td style="text-align: justify;" valign="middle"><span style="-webkit-border-horizontal-spacing: 0px; -webkit-border-vertical-spacing: 0px;"><span style="font-size: 12pt;"><span style="font-size: 10pt;"><span style="font-family: "comic sans ms", sans-serif;"><img style="float: left; border-width: 0px; border-color: #000000; margin: 12px;" src="./imagenes/foto7.JPG"  class="image" height="183" width="285">Cada salón está provisto de baño propio y accesorios antropométricos acordes a la edad. Están diseñados para tener cuatro zonas de actividades y materiales necesarios acordes a las diferentes edades: una <strong>zona motriz, de juegos, de actividades &nbsp;de interpretación, de arte y una zona tranquila</strong>.</span></span></span></span></td>
</tr>
<tr>
<td style="text-align: justify;" valign="middle"><span style="-webkit-border-horizontal-spacing: 0px; -webkit-border-vertical-spacing: 0px;"><span style="font-size: 12pt;"><span style="font-size: 10pt;"><span style="font-family: "comic sans ms", sans-serif;"><img style="float: right; border-width: 0px; border-color: #000000; margin: 12px;" src="./imagenes/foto6.JPG"  class="image" height="183" width="285">La variedad de materiales didácticos y lúdicos &nbsp;estimularán al niño a explorar, descubrir, &nbsp;y llegar a conclusiones lógicas.&nbsp;Se dispone de <strong>un salón audiovisual </strong>donde los niños disfrutaran de videos didácticos, un salón de usos múltiples y actividades como expresión musical y corporal.</span></span></span></span></td>
</tr>


</tbody>
</table>';
      
   

include("inc/pie.php");
?>
