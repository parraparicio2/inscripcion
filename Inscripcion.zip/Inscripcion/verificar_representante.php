<?php
  require_once("includes/funciones.php");
  $txtCodigo = "";
  $txtNombre = "";
  $sql = "select codigo_representante, nombre from tbl_representante where codigo_representante = '". $_POST['txtCodigoRepresentante']."'";
  $consulta = ejecutarConsulta($sql);
  if (mysqli_num_rows($consulta) > 0)
    {
      $campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC);
	  $txtCodigo = $campo['codigo_representante'];
	  $txtNombre = $campo['nombre'];
	}
      $valores = array('codigoRepresentante'=>$txtCodigo,'nombre'=>$txtNombre);							 
      echo json_encode($valores);	
	
?>
