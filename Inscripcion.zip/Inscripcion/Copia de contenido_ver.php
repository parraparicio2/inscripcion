<!DOCTYPE html><!--esto identifica que es html-->
<html>
<head>
  <meta name="description" content="Loma Linda ">
  <meta name="keywords" content="Preescolar"><!--keywords son la palabras claves que utilizan los buscadores para localizarla funciona como los tags-->
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/principal.css">
</head>
<body>
<?php 
include("includes/funciones.php");
?>
   <div id="agrupar">
   	<header id="titular">
	    <img src="imagenes/logo_reportes.jpeg">
         <h1>Preescolar Loma Linda</h1>
      </header>
      <nav>
        <ul>
           <li class="elemento">
              <a href="index.php">Inicio</a>
           </li>

           <li class="elemento">
              <a href="quienes_somos.html">Quienes Somos?</a>
           </li>
           <li class="elemento">
              <a href="mision.html">Mision y Vision</a>
           </li>
           <li class="elemento">
              <a href="menu.php">Sistema Intranet</a>
           </li>
           <li class="elemento">
              <a href="contactenos.html">Contáctenos</a>
           </li>
        </ul>
      </nav>
      <?php
	 $id_contenido=$_GET['id_contenido'];
	 $sql="select * from tbl_contenido where id_contenido = '$id_contenido'";
		//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta, MYSQLI_ASSOC))
		   {
			  $id_contenido=$campo['id_contenido'];
			  
	?>	
     <section id="seccion">
         <article>
            <header>
            	<h2><?php echo $campo['titulo']; ?></h2>
            </header>
            <div id="imagen_contenido">
                <a href="contenido_ver.php?id_contenido=<?php echo $id_contenido?>">
                   <img id='foto' src="cargarImagen.php?id_foto=<?php echo $id_contenido ?>"/>
                </a>   
            </div>    
                <p><?php echo $campo['descripcion']; ?></p>
               <footer>
               	<a href="javascript:window.location='index.php'">Volver a la página principal </a>
               </footer>
         </article>
<?php 
		   }
	    }
?>         
      <footer id="pie">
         <p><strong>Desarrollado para Preescolar Loma Linda, Maracaibo - Estado Zulia</strong></p>
      </footer><!--pie de pagina principal-->
   </div>
</body>
</html>

