<?php
include("includes/funciones.php");
abrirSesion();
//echo $_POST['txtmodo']; 
if ($_POST['txtModo']!="E")
{
	$sql="CALL sp_alumnos('".$_POST['txtCodigo']."','".$_POST['txtCodigoRepresentante']."','".$_POST['txtNombre']."','".formatoFecha($_POST['txtFechaNacimiento'])."','".$_POST['txtTipoSangre']."','".$_POST['txtAlergico']."','".$_POST['txtLugarNacimiento']."', '".$_POST['txtEstado']."' )";
	
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Guardado')</script>";

}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_alumnos where codigo_alumno = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	

?>
<script>
window.location = 'alumnos.php';
</script>