<!DOCTYPE HTML>
<html>
    <head>
        <title>
            ..:: trabajo ::..
        </title>
        <link rel='stylesheet' type='text/css'
        href='estilos/estilos.css'/>
       <link rel="stylesheet" href="css/principal.css">
<style type="text/css">
a {
	color: #333;
}
#nav {
	margin: 0;
	padding: 7px 50px 0;
	line-height: 100%;
	width:100%;
	
	border-radius: 2em;

	-webkit-border-radius: 2em;
	-moz-border-radius: 2em;
	
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .4);

	background: #ffff; /* for non-css3 browsers */
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#a9a9a9', endColorstr='#7a7a7a'); /* for IE */
	background: -webkit-gradient(linear, left top, left bottom, from(#a9a9a9), to(#7a7a7a)); /* for webkit browsers */
	background: -moz-linear-gradient(top,  #a9a9a9,  #7a7a7a); /* for firefox 3.6+ */

	border: solid 1px #6d6d6d;
}
#nav li {
	margin: 0 5px;
	padding: 0 0 8px;
	float: left;
	position: relative;
	list-style: none;
	font-family:Arial, Helvetica, sans-serif;
    padding-left:40px;
}
/* main level link */
#nav a {
	font-weight: bold;
	color:	#72C763; 
	
	text-decoration: none;
	display: block;
	padding:  8px 20px;
	margin: 0;
	-webkit-border-radius: 1.6em;
	-moz-border-radius: 1.6em;
	text-shadow: 0 1px 1px rgba(0, 0, 0, .3);
}
/* main level link hover */
#nav .current a, #nav li:hover > a {
	background: #d1d1d1; /* for non-css3 browsers */
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#ebebeb', endColorstr='#a1a1a1'); /* for IE */
	background: -webkit-gradient(linear, left top, left bottom, from(#ebebeb), to(#a1a1a1)); /* for webkit browsers */
	background: -moz-linear-gradient(top,  #ebebeb,  #a1a1a1); /* for firefox 3.6+ */

	color: #444;
	border-top: solid 1px #f8f8f8;
	-webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	-moz-box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
	text-shadow: 0 1px 0 rgba(255, 255, 255, .8);
}
/* sub levels link hover */
#nav ul li:hover a, #nav li:hover li a {
	background: none;
	border: none;
	color: #666;
	-webkit-box-shadow: none;
	-moz-box-shadow: none;
}
#nav ul a:hover {
	background: #0399d4 !important; /* for non-css3 browsers */
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#04acec', endColorstr='#0186ba'); /* for IE */
	background: -webkit-gradient(linear, left top, left bottom, from(#04acec), to(#0186ba)) !important; /* for webkit browsers */
	background: -moz-linear-gradient(top,  #04acec,  #0186ba) !important; /* for firefox 3.6+ */

	color: #fff !important;
	-webkit-border-radius: 0;
	-moz-border-radius: 0;
	text-shadow: 0 1px 1px rgba(0, 0, 0, .1);
}
/* level 2 list */
#nav ul {
	background: #ddd; /* for non-css3 browsers */
	filter:  progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffffff', endColorstr='#cfcfcf'); /* for IE */
	background: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#cfcfcf)); /* for webkit browsers */
	background: -moz-linear-gradient(top,  #fff,  #cfcfcf); /* for firefox 3.6+ */

	display: none;
	margin: 0;
	padding: 0;
	width: 185px;
	position: absolute;
	top: 35px;
	left: 0;
	border: solid 1px #b4b4b4;
	-webkit-border-radius: 10px;
	-moz-border-radius: 10px;
	border-radius: 10px;
	-webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	-moz-box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
	box-shadow: 0 1px 3px rgba(0, 0, 0, .3);
}
/* dropdown */
#nav li:hover > ul {
	display: block;
}
#nav ul li {
	float: none;
	margin: 0;
	padding: 0;
}
#nav ul a {
	font-weight: normal;
	text-shadow: 0 1px 1px rgba(255, 255, 255, .9);
}
/* level 3+ list */
#nav ul ul {
	left: 181px;
	top: -3px;
}
/* rounded corners for first and last child */
#nav ul li:first-child > a {
	-webkit-border-top-left-radius: 9px;
	-moz-border-radius-topleft: 9px;
	-webkit-border-top-right-radius: 9px;
	-moz-border-radius-topright: 9px;
}
#nav ul li:last-child > a {
	-webkit-border-bottom-left-radius: 9px;
	-moz-border-radius-bottomleft: 9px;
	-webkit-border-bottom-right-radius: 9px;
	-moz-border-radius-bottomright: 9px;
}
/* clearfix */
#nav:after {
	content: ".";
	display: block;
	clear: both;
	visibility: hidden;
	line-height: 0;
	height: 0;

}
#nav {
	display: inline-block;
}
html[xmlns] #nav {
	display: block;
}
* html #nav {
	height: 1%;
}
  
</style>
	   
	   
    </head>    


<body>

<?php 
include("includes/funciones.php");
?>
<div id="div_principal">


<div id='div_header'>

<img src="./imagenes/logo cabecera.JPG" width="990" height="101"> 

</div>


<div id='div_menu'>
<ul id="nav">
    
	<li><a href="index.php">Inicio</a><!--el boton principal-->
		<!--<ul>
            <li><a href="contenidos.php">Administrador de Contenidos</a></li>
		    <li><a href="periodos.php">Per�odos</a></li>
            <li><a href="representante.php">Representantes</a></li>
            <li><a href="alumnos.php">Alumnos</a></li>
            <li><a href="turno.php">Turnos</a></li>
            <li><a href="seccion.php">Secciones</a></li>
            <li><a href="usuarios.php">Usuarios</a></li>
			<!--li><a href="usuarios.php">Usuarios</a></li-
		</ul>-->
	</li>
		
	<li><a href="#">Preescolar</a>
		<ul>
            <li><a href="mision.html">vision y mision</a></li>
            <li><a href="consulta_inscripcion.php">directiva</a></li>
			<li><a href="inscripcion.php">instalaciones</a></li>
            <li><a href="consulta_inscripcion.php">preescolar</a></li>
		</ul>
	</li>
	<li><a href="#">Actualidad</a>
		<ul>
			<li><a href="listado_periodo.php">noticias</a></li>
			<li><a href="consulta_seccion.php">circulares</a></li>
			
		</ul>
	</li>
	<li><a href="#">Equipo</a>
		<ul>
			<li><a href="logout.php">personal directivo</a></li>
			<li><a href="logout.php">personal docente</a></li>
			
			
		</ul>
	</li>

	<li><a href="#">Inscripciones</a>
		
	</li>
	
	<li><a href="#">Contactos</a>
		
	</li>
	
	
</ul>

</div>

<div id='div_contenido'>

<h1> contenido</h1>

<div id='div_subcontenido'>


      <?php
	// $id_contenido=$_GET['id_contenido'];
	 $sql="select * from tbl_contenido";
		//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if (mysqli_num_rows($consulta) > 0)
	   { 
          while ($campo=mysqli_fetch_array($consulta))
		   {
			  $id_contenido=$campo['id_contenido'];
			  
	?>	
     <section id="seccion">
         <article>
            <header>
            	<h4><?php echo $campo['titulo']; ?></h4>
            </header>
            <div id="imagen_contenido">
                <a href="contenido_ver.php?id_contenido=<?php echo $id_contenido?>">
                   <img id='foto' src="cargarImagen.php?id_foto=<?php echo $id_contenido ?>"/>
                </a>   
            </div>    
                <p><?php echo $campo['descripcion']; ?></p>
           
         </article>
<?php 
		   }
	    }
?> 





<h1>subcontenido</h1>
</div>

<div id='div_interes'>

<h1> interes</h1>
</div>

</div>

<div id='div_pie'>

<h1> pie</h1>
</div>

</div>

</body>
</html>
