<?php
include("includes/funciones.php");
abrirSesion();
//echo $_POST['txtmodo']; 
if ($_POST['txtModo']!="E")
{
	$sql="call sp_turno('".$_POST['txtCodigo']."','".$_POST['txtDescripcion']."')";
	
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Guardado')</script>";

}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_turno where codigo_turno = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	

?>
<script>
window.location = 'turno.php';
</script>