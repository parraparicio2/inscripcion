<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="STYLESHEET" type="text/css" href="css/estilos.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/funciones.js"></script>
<title>Documento sin título</title>
</head>
<body>
<div id="contenedor" >
   <div id="main" >
<?php
include("includes/funciones.php");
abrirSesion();
abrirSesionAdministrador();
$txtcodigo_turno= "";
$txtdescripcion= "";
$txthora_inicio= "";
$txthora_final= "";
$txtmodo="I";
if(isset($_POST['txtcodigo_turno'])&& trim($_POST['txtcodigo_turno']<>""))
  {
     $sql="select * from tbl_turno where codigo_turno='".trim($_POST['txtcodigo_turno'])."'";
	//echo $sql;
	 $consulta=ejecutarConsulta($sql);
	 //echo $consulta;
	   if ($consulta)
	   { 
		   while ($campo=pg_fetch_array ($consulta))
		   {
			  $txtcodigo_turno=$campo['codigo_turno'];
			  $txtdescripcion=$campo['descripcion'];
			  $txthora_inicio=$campo['hora_inicio'];
			  $txthora_final=$campo['hora_final'];
		   }
	    }
	    else
			 {
			 	echo "<script> alert('Registro No Encontrado');</script>";
				$txtcodigo_turno=$_POST['txtcodigo_turno'];
			 }
	}
 
?>
<form id="frmturno" name="frmturno" method="post" action="">
<table width="561" height="209" border="1">
<tr>
  <th height="50" colspan="2" bgcolor="#339999" scope="col"><h2><em>TURNO</em></h2></th>
</tr>
<tr>
  <td width="197" height="44" bgcolor="#CCCCCC"><div align="center"><strong>CODIGO</strong></div></td>
  <td width="348" bgcolor="#CCCCCC">
  <label for="textturno"></label>
  <input type="text" name="txtcodigo_turno" id="txtcodigo_turno" value="<?php echo $txtcodigo_turno ?>" lang="El Turno" onblur="buscar()"/> 
  <input type ="button" onclick="abrirBusqueda('frmturno', 'txtcodigo_turno','busqueda.php',  sqlCodigo, sqlDescripcion, true)" /></td>
</tr>

<tr>
  <td height="39" bgcolor="#CCCCCC"><div align="center"><strong>DESCRIPCION</strong></div></td>
  <td bgcolor="#CCCCCC">
  <label for="textdescripcion"></label>
  <input type="text" name="txtdescripcion" id="txtdescripcion" size="40" maxlength="60"value="<?php echo $txtdescripcion ?>" lang="La Descripciòn"/>
  </td>
</tr>

<tr>
  <td height="39" bgcolor="#CCCCCC"><div align="center"><strong>HORA DE INICIO</strong></div></td>
  <td bgcolor="#CCCCCC">
  <label for="texthora_inicio"></label>
  <input type="text" name="txthora_inicio" id="txthora_inicio" value="<?php echo $txthora_inicio ?>" lang="Hora Inicio"/>
  </td>
</tr>

<tr>
  <td height="39" bgcolor="#CCCCCC"><div align="center"><strong>HORA FINAL</strong></div></td>
  <td bgcolor="#CCCCCC">
  <label for="texthora_final"></label>
  <input type="text" name="txthora_final" id="txthora_final" value="<?php echo $txthora_final ?>" lang="Hola Final"/>
  </td>
</tr>

  <tr>
    <td height="64" colspan="2" bgcolor="#CCCCCC"><div align="center">
        <input type="button" name="cdmeliminar" id="cdmeliminar" value="ELIMINAR" onclick="botonEliminar()" />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="button" name="cmdguardar" id="cmdguardar" value="GUARDAR" onclick="botonGuardar();"/>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="button" name="cmdsalir" id="cmdsalir" value="SALIR" onclick="window.top.location='menu.php'"/>
        </span></div></td>
  </tr>
  </table>
  <input id="txtmodo" name="txtmodo" type="hidden"value="<?php echo $txtmodo?>" />
</form>
<script>
 var sqlCodigo = 'select codigo_turno, descripcion from tbl_turno where codigo_turno ilike \'%@parametro_codigo%\'';
 var sqlDescripcion = 'select codigo_turno, descripcion from tbl_turno where descripcion ilike \'%@parametro_descripcion%\'';
   function botonGuardar()
   {
	  
      document.frmturno.action='registrar_turno.php';  
	  frmturno.submit();
	  
   }
   function buscar()
   {

	  document.frmturno.action='frmturno.php'; 
	  frmturno.submit();
   }
   
  function botonEliminar()
   {
	  document.frmturno.txtmodo.value='E';
      document.frmturno.action='registrar_turno.php';  
	  frmturno.submit();	  
   }
 </script>
 </div>
 </div>
</body>
</html>