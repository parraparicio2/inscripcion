<?php 
include("includes/funciones.php");
include("inc/cabecera2.php");


  echo' <div id="agrupar">
  
      <article>
            <header>
            	<h2>Misión</h2>
            </header>
             
                <p>El Centro de Educación Inicial Loma Linda tiene como misión preparar y capacitar al niño y la niña para su ingreso a la educación básica, facilitando experiencias que le permitan la base para el desarrollo de una persona autónoma, con espíritu de equidad, tomando en cuenta a la familia y su entorno social.</p>
               <footer>
              
               </footer>
         </article>
         <article>
            <header>
            	<h2>Visión</h2>
            </header>
                
                <p>El Centro de Educación Inicial Loma Linda, tiene como visión lograr la integración y participación de los padres, representantes y responsables de los niños (a) del preescolar, así mismo  que tengan participación protagónica para el buen funcionamiento de la organización educativa, para así garantizar una educación de calidad.</p>
               <footer>
             
               </footer>
         </article></div>';
      
   

include("inc/pie.php");
?>
