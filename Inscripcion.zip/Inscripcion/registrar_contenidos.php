<?php
include("includes/funciones.php");
include("includes/SimpleImage.php");
abrirSesion();
//echo $_POST['txtmodo']; 
$login = $_SESSION['login'];
 $carpeta="tmp/";
if ($_POST['txtModo']!="E")
{
	
if (!empty($_FILES['archivo1']['name']))
	{
     $image = new SimpleImage();
     $image->load($_FILES['archivo1']['tmp_name']);
     $image->resizeToWidth(400);
     $image->save($_FILES['archivo1']['tmp_name']);

	  $fileName1 = $_FILES['archivo1']['name'];
	  $tmpName1  = $_FILES['archivo1']['tmp_name'];
	  
	  $fileType1 = $_FILES['archivo1']['type'];
	  $fileSize1 = $_FILES['archivo1']['size'];

	  $foto1 = transformarImagen($fileName1, $tmpName1, $fileSize1);
	  unlink($carpeta.basename($fileName1));

	}
else
  {
	  echo "<script>
	         alert('Debe Ingresar una Imagen');
			 window.history.back();
	         </script>";
	  
  }		
	
	$sql="CALL sp_contenido('".$_POST['txtCodigo']."',
	                         '".$login."',
	                         '".$_POST['txtTitulo']."',
							 '".$_POST['txtDescripcion']."',
							 '".formatoFecha($_POST['txtFechaInicio'])."',
							 '".formatoFecha($_POST['txtFechaFin'])."',
							 '".$_POST['txtResumen']."',
							 '".$foto1."',
							 '".$fileSize1."',
							 '".$fileType1."')";
							 
						 
	

	$consulta=ejecutarConsulta($sql);
	//echo $sql;
	
	echo "<script>alert('Registro Guardado')</script>";
   
  // if (!empty($_FILES['archivo1']['name']))
//	   unlink($carpeta.basename($fileName1));
}
else if ($_GET['txtModo']=="E")
{
	$sql="delete from tbl_contenido where id_contenido = '".$_GET['id_contenido']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	

?>
<script>
window.location = 'contenidos.php';
</script>