<?php
include("includes/funciones.php");
abrirSesion();
//echo $_POST['txtmodo']; 
if ($_POST['txtModo']!="E")
{

	$sql="CALL sp_usuario('".$_POST['txtCodigo']."','".$_POST['txtNombre']."','".$_POST['txtCorreo']."','".$_POST['txtTelefono']."','".$_POST['txtDireccion']."','".$_POST['txtClave']."','".$_POST['txtTipo']."')";
	
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Guardado')</script>";

}
else if ($_POST['txtModo']=="E")
{
	$sql="delete from tbl_usuario where login = '".$_POST['txtCodigo']."'";
	$consulta=ejecutarConsulta($sql);
	echo "<script>alert('Registro Eliminado')</script>";

}
//echo $sql;	

?>
<script>
window.location = 'usuarios.php';
</script>