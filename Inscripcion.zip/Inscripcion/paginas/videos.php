<?php
include('./inc/cabecera.php');


echo('lo que coloquemos aqui siempre va para el mero medio');

include('inc/pie.php');
?>