<?php 
include("includes/funciones.php");
include("inc/cabecera2.php");


  echo' 
   <div id="agrupar">
  
   <div id="main">
      
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
  <div id="header_formulario">Pre-inscripcion
  </div><!--cabecera-->
<table border="0" height="100%" width="100%">
<tbody><tr>
  <th colspan="2" scope="col" height="50"></th>
</tr>
<tr>
  <td class="etiqueta" height="45" width="100">Código</td>
  <td width="348">
  <input name="txtCodigo" id="txtCodigo" value="" onblur="buscar()" class="txt_mediano" lang="El Código" type="text"> 
  <input onclick="abrirBusqueda("frmDatos", "txtCodigo","busqueda.php",  sqlCodigo, sqlDescripcion, 1)" id="boton_browse" value="..." type="button"></td>
</tr>

<tr>
  <td class="etiqueta" height="45">Nombre</td>
  <td>
  <input name="txtNombre" id="txtNombre" size="40" maxlength="60" value="" class="txt_largo" lang="El Nombre" type="text">
  </td>
</tr>
<tr>
  <td class="etiqueta" height="45">Dirección</td>
  <td>
  <input name="txtDireccion" id="txtDireccion" size="40" maxlength="60" value="" class="txt_largo" lang="La Dirección" type="text">
  </td>
</tr>
<tr>
  <td class="etiqueta" height="45">Teléfono</td>
  <td>
  <input name="txtTelefono" id="txtTelefono" size="40" maxlength="60" value="" class="txt_largo" lang="El Teléfono" type="text">
  </td>
</tr>
<tr>
  <td class="etiqueta" height="45">Correo</td>
  <td>
  <input name="txtCorreo" id="txtCorreo" size="40" maxlength="60" value="" class="txt_largo" lang="El Correo" type="text">
  </td>
</tr>

<tr>
  <td class="etiqueta" height="45">Conyugue</td>
  <td>
  <input name="txtConyugue" id="txtConyugue" size="40" maxlength="60" value="" class="txt_largo" lang="El Conyugue" type="text">
   <input id="txtModo" name="txtModo" type="hidden"value="<?php echo $txtModo?>" />
</form>
</td>
</tr>

 
 
 










      
<form id="frmDatos" name="frmDatos" method="post" action="" class="formulario">
 
<tr>
  <td class="etiqueta" height="45" width="100">Código</td>
  <td width="348">
  <input name="txtCodigo" id="txtCodigo" value="" onblur="buscar()" class="txt_mediano" lang="El Código" type="text"> 

  <input onclick="abrirBusqueda("frmDatos", "txtCodigo","busqueda.php",  sqlCodigo, sqlDescripcion, 1)" id="boton_browse" value="..." type="button"></td>

</tr>

<tr>
  <td class="etiqueta" height="45">Nombre</td>
  <td>
  <input name="txtNombre" id="txtNombre" size="40" maxlength="60" value="" class="txt_largo" lang="El Nombre" type="text">
  </td>
</tr>
<tr>
  <td class="etiqueta" height="45">Fecha Nacimiento</td>
  <td>
  <input name="txtFechaNacimiento" id="txtFechaNacimiento" size="40" maxlength="60" value="" class="txt_mediano" lang="La Fecha de Nacimiento" type="text"><img src="imagenes/calendar.gif" alt="" id="img_calendario" height="16" width="16"> DD/MM/AAAA
  </td>
</tr>
<tr>
  <td class="etiqueta" height="45">Tipo de Sangre</td>
  <td>
  <input name="txtTipoSangre" id="txtTipoSangre" size="40" maxlength="60" value="" class="txt_largo" lang="El Tipo de Sangre" type="text">
  </td>
</tr>

<tr>
  <td class="etiqueta" height="45">Alergico a </td>
  <td>
  <input name="txtAlergico" id="txtAlergico" size="40" maxlength="60" value="" class="txt_largo" lang="Sí es alergico" type="text">
  </td>
</tr>

<tr>
  <td class="etiqueta" height="45">Código del Representante</td>
  <td>
  <input name="txtCodigoRepresentante" id="txtCodigoRepresentante" value="" class="txt_mediano" onblur="buscarRepresentante()" lang="El Representante" type="text"> <input onclick="abrirBusqueda("frmDatos", "txtCodigoRepresentante","busqueda.php",  sqlCodigoRepresentante, sqlDescripcionRepresentante, 1)" id="boton_browse" value="..." type="button"><span id="nombreRepresentante" class="etiqueta"></span>
  </td>
</tr>
  <tr>
    <td colspan="2" height="100"><div align="center">
      <input name="cdmeliminar" id="cdmeliminar" value="Eliminar" onclick="botonEliminar()" class="boton_comando" type="button">
      <input name="cmdguardar" id="cmdguardar" value="Guardar" onclick="botonGuardar();" class="boton_comando" type="button">
      <input name="cmdsalir" id="cmdsalir" value="Salir" onclick="window.top.location="menu.php"" class="boton_comando" type="button">
    
  
  <input id="txtModo" name="txtModo" value="I" type="hidden">
</form>










   </div>
      </td>
  </tr>
  
  
  
  
  
  
  
  
  
  </tbody></table>
  

 </div> </div>';
      
   

include('inc/pie.php');
?>
